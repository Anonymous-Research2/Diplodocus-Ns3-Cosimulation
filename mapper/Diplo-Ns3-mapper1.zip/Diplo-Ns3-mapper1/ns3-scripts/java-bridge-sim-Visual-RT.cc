
// =============================================================================
//  java-bridge-sim-Visual-RT.cc — the NS-3 side of the Diplodocus <-> NS-3 bridge
// =============================================================================
//
// WHAT THIS SCRIPT DOES
// -----------------------
// This is a small, custom NS-3 simulation of two directly-connected network
// nodes (node 0 and node 1), (of course will extedn it so it will capture the nodes descibed in Diplodocus design) controlled from the outside by a Java program
// (see DiploToNs3Mapper.java / Ns3RunnerVisual.java).
//
// For each command it is asked to simulate, this script:
//   1. Sends one ICMP ping from node 0 to node 1, using the requested packet 
//      size (in bytes).
//   2. Measures the real round-trip time (RTT) that NS-3's own physical/link
//      layer simulation produces for that ping.
//   3. Prints the measured latency to standard output in a simple,
//      machine-readable format that the Java side can parse:
//
//          RESULT_START
//          measuredLatencyNs=<value>
//          RESULT_END
//
// HOW IT HANDLES MULTIPLE COMMANDS IN A SINGLE RUN
// ---------------------------------------------------
// Rather than exiting after the first ping, this script keeps running and
// listens on a local UDP port (9999) for additional commands sent by the
// Java side while the simulation is still active. This lets the same NS-3
// process handle several commands, one after another, without needing to be
// restarted for each one - which would otherwise be slow and would reset the
// simulated network state every time.
//
// Because this script needs to react to messages arriving from an external
// program WHILE the simulation is running, it uses NS-3's
// "RealtimeSimulatorImpl": normally, NS-3 runs its simulated clock as fast as
// the CPU allows, with no relationship to real (wall-clock) time. In realtime
// mode, the simulated clock is instead kept in step with the real clock,
// which is what makes it meaningful to "inject" a new external command at an
// arbitrary moment and have the simulation react to it right away.
// I know this could be a problem for real time synchronisation, but so far I try
// to see if NS-3 could deal with realtime execution.
//
// HOW THE FIRST vs LATER COMMANDS ARE PROVIDED
// -----------------------------------------------
//   - The FIRST command's parameters (--nsValue and --packetSize) are passed
//     as command-line arguments when this script is launched by Java (see
//     Ns3RunnerVisual.start()). --nsValue sets the simulated link's data
//     rate; --packetSize sets the size of the very first ping.
//   - Every LATER command only changes the ping's packet size, and arrives as
//     a short UDP text message ("packetSize=<value>") sent by Java to port
//     9999 (see Ns3RunnerVisual.sendCommand()). Each time one of these
//     messages arrives, this script installs and starts a brand-new Ping
//     application between the same two nodes, using the requested size.
//
// VISUALISATION (you can ignore it so far)
// ----------------
// This script also records a NetAnim trace file (/tmp/java-bridge-sim.xml),
// so that everything simulated in this run (both nodes and every ping sent
// between them) can afterwards be replayed visually in the NetAnim viewer.
 
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/internet-apps-module.h"
#include "ns3/netanim-module.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>

using namespace ns3;

static int g_udpSock = -1;
static NodeContainer g_nodes;
static Ipv4InterfaceContainer g_interfaces;

// --- Callback pour la 1ère ping, connectée AVANT Simulator::Run() via Config::Connect
//     (celui-ci REÇOIT un "context" en premier paramètre)
static void RttCallback (std::string context, uint16_t seq, Time rtt)
{
  std::cout << "RESULT_START" << std::endl;
  std::cout << "measuredLatencyNs=" << rtt.GetNanoSeconds () << std::endl;
  std::cout << "RESULT_END" << std::endl;
}

// --- Callback pour les pings injectées APRES coup, connectées directement
//     via TraceConnectWithoutContext (PAS de "context" en paramètre)
static void RttCallbackNoContext (uint16_t seq, Time rtt)
{
  std::cout << "RESULT_START" << std::endl;
  std::cout << "measuredLatencyNs=" << rtt.GetNanoSeconds () << std::endl;
  std::cout << "RESULT_END" << std::endl;
}

static void PollForNewCommand ()
{
  char buf[256];
  ssize_t n = recv (g_udpSock, buf, sizeof(buf) - 1, MSG_DONTWAIT);
  if (n > 0)
    {
      buf[n] = '\0';
      std::string msg (buf);
      std::cout << "[bridge] Nouvelle commande reçue: " << msg << std::endl;

      uint32_t newSize = 512;
      size_t pos = msg.find ("packetSize=");
      if (pos != std::string::npos)
        {
          newSize = std::stoul (msg.substr (pos + strlen ("packetSize=")));
        }

      PingHelper ping (g_interfaces.GetAddress (1));
      ping.SetAttribute ("Size", UintegerValue (newSize));
      ping.SetAttribute ("Count", UintegerValue (1));
      ApplicationContainer app = ping.Install (g_nodes.Get (0));
      app.Start (Simulator::Now () + Seconds (0.1));
      app.Stop  (Simulator::Now () + Seconds (4.0));

      Ptr<Ping> pingApp = DynamicCast<Ping> (app.Get (0));
      pingApp->TraceConnectWithoutContext ("Rtt", MakeCallback (&RttCallbackNoContext));

      std::cout << "[bridge] Nouveau ping injecté, size=" << newSize << " bytes" << std::endl;
    }

  Simulator::Schedule (MilliSeconds (50), &PollForNewCommand);
}

int main (int argc, char *argv[])
{
  GlobalValue::Bind ("SimulatorImplementationType",
                      StringValue ("ns3::RealtimeSimulatorImpl"));

  // Default values, overridden below by whatever the Java side passes in.
  double nsValue = 5.0e7;
  uint32_t packetSize = 512;

  CommandLine cmd;
  cmd.AddValue ("nsValue", "Link data rate (bps)", nsValue);
  cmd.AddValue ("packetSize", "Ping packet size (bytes)", packetSize);
  cmd.Parse (argc, argv);

  // --- Build the topology: two nodes, directly connected point-to-point.
  g_nodes.Create (2);

  PointToPointHelper p2p;
  p2p.SetDeviceAttribute ("DataRate", DataRateValue (DataRate (nsValue)));
  p2p.SetChannelAttribute ("Delay", StringValue ("2ms"));
  NetDeviceContainer devices = p2p.Install (g_nodes);

  InternetStackHelper stack;
  stack.Install (g_nodes);

  Ipv4AddressHelper address;
  address.SetBase ("10.1.1.0", "255.255.255.0");
  g_interfaces = address.Assign (devices);

  // --- 1ère ping (ta commande Diplodocus initiale)
  PingHelper ping (g_interfaces.GetAddress (1));
  ping.SetAttribute ("Size", UintegerValue (packetSize));
  ping.SetAttribute ("Count", UintegerValue (1));
  ApplicationContainer apps = ping.Install (g_nodes.Get (0));
  apps.Start (Seconds (1.0));
  apps.Stop  (Seconds (5.0));

  // --- Connecté AVEC context, car câblé avant Simulator::Run()
  Config::Connect ("/NodeList/*/ApplicationList/*/$ns3::Ping/Rtt",
                    MakeCallback (&RttCallback));

  // --- Open the UDP socket that later commands will be sent to.
  g_udpSock = socket (AF_INET, SOCK_DGRAM, 0);
  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = INADDR_ANY;
  addr.sin_port = htons (9999);
  bind (g_udpSock, (sockaddr*)&addr, sizeof(addr));
  int flags = fcntl (g_udpSock, F_GETFL, 0);
  fcntl (g_udpSock, F_SETFL, flags | O_NONBLOCK);

  Simulator::Schedule (MilliSeconds (50), &PollForNewCommand);

  AnimationInterface anim ("/tmp/java-bridge-sim.xml");
  anim.SetConstantPosition (g_nodes.Get (0), 0.0, 0.0);
  anim.SetConstantPosition (g_nodes.Get (1), 10.0, 0.0);

  Simulator::Stop (Seconds (120.0));

  Simulator::Run ();
  Simulator::Destroy ();
  close (g_udpSock);

  return 0;
}
