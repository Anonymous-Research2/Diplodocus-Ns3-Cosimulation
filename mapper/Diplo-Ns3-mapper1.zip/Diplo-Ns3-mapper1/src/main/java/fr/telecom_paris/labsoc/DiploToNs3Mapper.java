package fr.telecom_paris.labsoc;

import org.apache.jena.datatypes.xsd.XSDDatatype;
import org.apache.jena.ontology.*;
import org.apache.jena.rdf.model.*;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.query.*;
import org.apache.jena.riot.RDFFormat;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;

import openllet.jena.PelletReasonerFactory;

import org.apache.jena.util.iterator.ExtendedIterator;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ============================================================================
 *  DiploToNs3Mapper — Ontology-driven bridge between Diplodocus and NS-3
 *  (CONCURRENT version: several commands can be "in flight" in NS-3 at once)
 * ============================================================================
 *
 * WHAT THIS PROGRAM DOES
 * -----------------------
 * This program connects two different simulators that know nothing about each
 * other, using OWL ontologies as the "translation layer" between them:
 *
 *   - Diplodocus: an abstract system-level simulator that reasons in terms of
 *     "master clock cycles" (an integer/decimal counter, not real time).
 *   - NS-3: a real network simulator that reasons in real time (nanoseconds)
 *     and actually sends packets between simulated network nodes.
 *
 * The two simulators are described by two separate OWL ontologies:
 *   - diplodocus.owl.ttl  -> vocabulary and individuals for Diplodocus
 *   - ns3.owl.ttl         -> vocabulary and individuals for NS-3
 * and a third ontology, mapping.owl.ttl, declares how concepts in one relate
 * to concepts in the other (class equivalences, property equivalences, and
 * SWRL rules that convert numeric values between the two worlds). Both the
 * class/property equivalences and the arithmetic conversions are handled by
 * the Openllet/Pellet OWL+SWRL reasoner - this Java program never re-derives
 * the formulas itself, it simply reads the values the reasoner has already
 * computed.
 *
 * THE FULL LOOP, IN PLAIN WORDS
 * ------------------------------
 *   1. A "command" appears in diplodocus.owl.ttl: it describes a chunk of data
 *      to send (its size) and the Diplodocus clock cycle at which sending
 *      should start.
 *   2. This program detects the new command as soon as it is written, uses
 *      the mapping ontology to translate its Diplodocus values into NS-3
 *      values (packet size in bytes, and an equivalent "ns" timing value),
 *      and ASKS NS-3 to simulate sending a packet of that size between two
 *      network nodes - WITHOUT waiting for NS-3 to finish (see below).
 *   3. Whenever NS-3 reports back the real (simulated) latency it measured,
 *      in nanoseconds, for a given command, this program records that result
 *      as a new individual in ns3.owl.ttl.
 *   4. Immediately afterwards, still for that same command, it converts the
 *      latency back into Diplodocus clock cycles (again via the mapping
 *      ontology / SWRL rules) and writes the resulting "end cycle" back into
 *      diplodocus.owl.ttl, linked to the exact command that triggered it.
 *
 * Steps 1-2 are referred to below as "Direction 1" (Diplodocus -> NS-3), and
 * steps 3-4 as "Direction 2" (NS-3 -> Diplodocus).
 *
 * SENDER / RECEIVER HANDLING (ONE NS-3 COMMAND -> TWO RESULTS)
 * ----------------------------------------------------------------
 * A SenderNI command and a ReceiverNI command describe the two ends of the
 * SAME network transfer, so only ONE command is sent to NS-3:
 *
 *   - Commands whose name contains "ReceiverNI" are FILTERED OUT: they are
 *     never sent to NS-3. Their start cycle and name are only remembered
 *     (PipelineState.receiverStartCycles, keyed by receiver command name).
 *   - The SenderNI command is sent to NS-3, and TWO results are awaited:
 *       * the SEND latency    -> "NET_DONE App1__SenderNI   <endCycle>"
 *       * the RECEIVE latency -> "NET_DONE App1__ReceiverNI <endCycle>"
 *     (the receive one is obtained through runnerV.getReceiveFuture(id)).
 *     For each, endCycle = startCycle + round(latencyNs * f / 1e9).
 *
 * CONCURRENCY: SEVERAL PACKETS IN FLIGHT AT ONCE
 * ----------------------------------------------------
 * A real network simulation should be able to reflect several Diplodocus
 * tasks sending traffic around the same time, with more than one packet
 * genuinely in transit in NS-3 simultaneously - not one packet being fully
 * simulated from start to finish before the next is even allowed to start.
 * This program is built around that idea:
 *
 *   - Sending a command to NS-3 (via Ns3RunnerVisual.start() / .sendCommandAsync())
 *     never blocks. It returns immediately with a
 *     java.util.concurrent.CompletableFuture<Double> - a placeholder for "the
 *     measured latency, whenever it arrives".
 *   - As soon as that future is obtained, this program moves straight on to
 *     the NEXT new command, if there is one - it does not wait.
 *   - Each command sent to NS-3 carries its own unique id. NS-3 always
 *     reports which id a given result belongs to, so results can be matched
 *     back to the right command even if they complete in a different order
 *     than they were submitted (which can now genuinely happen, since
 *     several pings may be racing each other on the same simulated link).
 *   - Direction 2 for a given command is attached as a continuation
 *     ("resultFuture.whenComplete(...)") that runs automatically, as soon as
 *     - and only when - that specific command's result becomes available.
 *     Different commands' Direction 2 processing can therefore happen one
 *     after another as results trickle in, without any of them blocking the
 *     submission of further Direction 1 commands.
 *
 * HOW THIS PROGRAM RUNS - EVENT-DRIVEN, NOT POLLING
 * -----------------------------------------------------
 *   - A background thread (the "command generator") invents new random
 *     commands and writes them into diplodocus.owl.ttl at random intervals,
 *     standing in for whatever real, external system would normally be
 *     producing these commands. Each generated command is stamped with an
 *     increasing sequence number (dip:commandSequenceNumber), used purely so
 *     that if several commands are ever discovered together in the same
 *     batch, this program submits them to NS-3 in the order they were
 *     actually created (their eventual RESULTS may still complete in a
 *     different order, once concurrency is in play - that's expected).
 *   - The main thread does NOT repeatedly re-check the file on a timer.
 *     Instead, it registers a filesystem WatchService on the folder
 *     containing diplodocus.owl.ttl, and waits (using no CPU) until the
 *     operating system notifies it that the file has changed, then
 *     immediately submits whatever new command(s) are there.
 *   - A single, long-lived NS-3 process is used for the whole session: the
 *     very first command starts it (java-bridge-sim-Visual-RT.cc), and every
 *     following command is sent to that SAME running process over a small
 *     UDP "control channel" - so NS-3 does not need to be restarted for
 *     every command, and several of its simulated pings can be in flight on
 *     the link at once.
 *   - Because several threads can now touch shared state (the main thread
 *     submitting commands, the generator thread writing new ones, and NS-3's
 *     background result-reading thread running Direction 2 continuations),
 *     every access to diplodocus.owl.ttl is wrapped in a
 *     "synchronized (DIPLO_LOCK)" block. ns3.owl.ttl, on the other hand, is
 *     only ever touched from within these Direction-2 continuations, which
 *     always run one at a time (see "THREADING DETAILS" below) - so it needs
 *     no extra locking of its own.
 *
 * THREADING DETAILS
 * ---------------------
 * NS-3's result-reading background thread (inside Ns3RunnerVisual) processes
 * one RESULT_START...RESULT_END block from NS-3's console output at a time,
 * in a simple sequential loop, and completes each command's
 * CompletableFuture right there. Java's CompletableFuture, by default, runs
 * a ".whenComplete(...)" continuation directly on whichever thread called
 * "complete()" - which is always this SAME single background thread here.
 * This means every Direction 2 continuation (building ns3.owl.ttl
 * individuals, then reading/writing diplodocus.owl.ttl) is automatically
 * serialized, one command at a time, even though several commands may be
 * "in flight" inside NS-3 itself at once - so no extra locking is needed
 * around ns3Model or ns3.owl.ttl specifically.
 *
 * THE MAPPING RULES (declared in mapping.owl.ttl, applied by the reasoner)
 * --------------------------------------------------------------------------
 *   PART A (class equivalence):
 *     dip:DataQuantity   <=> ns3:Packet
 *     dip:NetTask        <=> ns3:Socket
 *     dip:CycleTimePoint <=> ns3:NsTimePoint
 *   PART B (property equivalence):
 *     dip:DataSize       <=> ns3:PacketSize
 *   PART C (SWRL rule, Diplodocus -> NS-3):
 *     nsValue = cycleValue * (1e9 / FrequencyHz)
 *   PART D (SWRL rule, NS-3 -> Diplodocus):
 *     delay_cycles = measuredLatencyNs * (FrequencyHz / 1e9)
 *     endCycle     = startCycleValue + delay_cycles
 *
 * A NOTE ON NUMBER TYPES
 * ------------------------
 * In the ontology, dip:DataSize has range xsd:integer, while dip:cycleValue
 * has range xsd:double (on purpose: the SWRL formulas above naturally produce
 * decimal results, e.g. 84.2158). Wherever this program writes a new literal
 * for one of these two properties, it explicitly builds a typed literal
 * (XSDDatatype.XSDinteger / XSDDatatype.XSDdouble) instead of just passing a
 * Java int - Jena's generic "addLiteral" would otherwise silently pick a
 * mismatching XSD type (such as xsd:long), which the reasoner would reject
 * as inconsistent with the property's declared range.
 * dip:commandSequenceNumber (introduced by this program purely for ordering
 * a batch's submission order, see above) is not referenced by any SWRL rule
 * or equivalence axiom, so it carries no such risk and is written as a plain
 * xsd:long.
 */
public class DiploToNs3Mapper {

    // --- Ontology namespace prefixes, used to build full URIs for every class
    //     and property referenced below (DIP = Diplodocus, NS3 = ns-3).
    static final String DIP = "http://labsoc.telecom-paris.fr/diplodocus#";
    static final String NS3 = "http://labsoc.telecom-paris.fr/ns3#";

    // --- Shared lock: every read or write of diplodocus.owl.ttl (from the
    //     generator thread, or from a Direction-2 continuation) happens
    //     inside "synchronized (DIPLO_LOCK) { ... }", so writers can never
    //     interleave and corrupt the file.
    static final Object DIPLO_LOCK = new Object();

    // Result of the start-up model check
    static volatile boolean MODEL_REJECTED = false;
    /** sender NI task (short name) -> ";transport=UDP;errorRate=0.02" / ";transport=TCP;sndBuf=32" */
    static final Map<String, String> NB_TRANSPORT = new java.util.concurrent.ConcurrentHashMap<>();

    // ---- NI task roles and pairs, from netbridge.conf (same file as the C++ side)
    //      line: <senderTask> <receiverTask> <senderNode> <receiverNode>
    static final String NETBRIDGE_CONF = "/home/isso84/TTool-ns3/simulators/c++2/netbridge.conf";
    static final Map<String, String>  NB_SENDER_TO_RECEIVER = new HashMap<>();
    static final Map<String, String>  NB_RECEIVER_TO_SENDER = new HashMap<>();
    static final Map<String, Integer> NB_SENDER_NODE        = new HashMap<>();
    static {
        try (BufferedReader br = new BufferedReader(new FileReader(NETBRIDGE_CONF))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#") || line.startsWith("model ")) continue;
                String[] p = line.split("\\s+");
                if (p.length < 2) continue;
                String s = shortName(p[0]), r = shortName(p[1]);
                NB_SENDER_TO_RECEIVER.put(s, r);
                NB_RECEIVER_TO_SENDER.put(r, s);
                NB_SENDER_NODE.put(s, p.length > 2 ? Integer.parseInt(p[2]) : 0);
                System.out.println("[netbridge.conf] " + s + " -> " + r
                        + " senderNode=" + NB_SENDER_NODE.get(s));
            }
        } catch (IOException e) {
            System.out.println("[netbridge.conf] ERROR cannot read " + NETBRIDGE_CONF);
        }
    }
    /** "WACS__SubTxNI" or "SubTxNI" -> "SubTxNI" (drops the application prefix) */
    static String shortName(String t) {
        int p = t.lastIndexOf("__");
        return p < 0 ? t : t.substring(p + 2);
    }
    /** "cmd_WACS__SubTxNI_iter1_WriteCmd" -> "SubTxNI" */
    static String taskOf(String cmdLocalName) {
        String t = cmdLocalName.startsWith("cmd_") ? cmdLocalName.substring(4) : cmdLocalName;
        return shortName(t.replaceAll("(_iter\\d+)?_WriteCmd$", ""));
    }

    // Cross-process lock: also taken by Diplodocus (C++) before it appends a command
    static java.nio.channels.FileLock lockDiploFile() throws IOException {
        java.nio.channels.FileChannel ch = java.nio.channels.FileChannel.open(
                Paths.get("diplodocus.owl.ttl.lock"),
                java.nio.file.StandardOpenOption.CREATE,
                java.nio.file.StandardOpenOption.WRITE);
        return ch.lock();
    }
    static void unlockDiploFile(java.nio.channels.FileLock fl) {
        if (fl == null) return;
        try { fl.release(); fl.channel().close(); } catch (IOException e) { e.printStackTrace(); }
    }

    // --- Side-channel file read by the Diplodocus C++ simulator, and the lock
    //     protecting writes to it (sender and receiver results may arrive
    //     close together).
    static final String SIDE_CHANNEL_PATH =
            "/home/isso84/TTool-ns3/simulators/c++2/net_done.sidechannel";
    static final Object SIDE_CHANNEL_LOCK = new Object();

    // --- Task names written to the side-channel for the two ends of the transfer.
    // File written by the C++ side (OntologyBridgeTask) with the ReceiverNI
    // start cycles. One line per iteration: "<startCycle> <iteration>".
    static final String RECEIVER_START_FILE =
            "/home/isso84/TTool-ns3/simulators/c++2/net_done.sidechannel.receiver_start";

    // Sender/receiver task names are NOT hardcoded any more: they are derived
    // from each command name (e.g. "cmd_App1__Sender1NI_iter1_WriteCmd" ->
    // sender task "App1__Sender1NI", paired receiver task "App1__Receiver1NI").
    // Per-receiver start-cycle files: RECEIVER_START_FILE + "." + "cmd_" + receiverTaskName

    // --- Random command generator settings: tune these to change how many
    //     commands get generated, how large/fast they are, and for how long.

    /*
    static final int[]  RANDOM_PACKET_SIZES   = {256}; // bytes // size of data transfered
    static final int    RANDOM_CYCLE_MIN      = 1000; // current cycle of Diplodocus
    static final int    RANDOM_CYCLE_MAX      = 20000;
    static final long   GEN_INTERVAL_MIN_MS   = 2000;   // shortest random delay between two generated commands
    static final long   GEN_INTERVAL_MAX_MS   = 3000;   // longest random delay between two generated commands
    static final long   GENERATOR_DURATION_MS = 10000;  // the generator stops producing new commands after this long
    */

    /*
    static final int[]  RANDOM_PACKET_SIZES   = {256};   // une seule taille, pour comparer facilement
    static final int    RANDOM_CYCLE_MIN      = 1000;
    static final int    RANDOM_CYCLE_MAX      = 20000;
    static final long   GEN_INTERVAL_MIN_MS   = 50;       // BIEN plus rapide que les ~237ms de service
    static final long   GEN_INTERVAL_MAX_MS   = 150;      // toujours plus rapide que le service
    static final long   GENERATOR_DURATION_MS = 5000;     // rafale de ~5s, assez pour ~30-50 paquets
    */

    static final int[]  RANDOM_PACKET_SIZES   = {256};   // une seule taille, pour comparer facilement
    static final int    RANDOM_CYCLE_MIN      = 1000;
    static final int    RANDOM_CYCLE_MAX      = 20000;
    static final long   GEN_INTERVAL_MIN_MS   = 100;       // BIEN plus rapide que les ~237ms de service
    static final long   GEN_INTERVAL_MAX_MS   = 150;      // toujours plus rapide que le service
    static final long   GENERATOR_DURATION_MS = 3000;     // rafale de ~5s, assez pour ~30-50 paquets

    // --- Main event loop settings.
    static final long TOTAL_DURATION_MS  = 90000;  // total runtime of the whole program; kept longer than
                                                     // GENERATOR_DURATION_MS so the last commands generated
                                                     // still have time to be submitted and answered before
                                                     // the program stops.
    static final long WATCH_POLL_TIMEOUT_MS = 500;  // how often the wait loop wakes up just to re-check the
                                                     // overall time budget above; NOT a processing delay - any
                                                     // actual file change is reacted to immediately.

    // How long to wait for a SINGLE command's own result before giving up on
    // it specifically (does not affect any other command, since each has its
    // own independent future now).
    static final long NS3_RESULT_TIMEOUT_SECONDS = 180;

    // How long, at the very end of the run, to wait for any commands whose
    // result was still "in flight" when the timed loop ended.
    static final long FINAL_DRAIN_TIMEOUT_SECONDS = NS3_RESULT_TIMEOUT_SECONDS + 15;

    // Global counter used to stamp every generated command with a unique,
    // strictly increasing sequence number, purely to recover creation order
    // when several commands are discovered together in one batch.
    static final AtomicInteger cmdSequenceCounter = new AtomicInteger(0);

    public static void main(String[] args) throws IOException, InterruptedException {

        // ============================================================
        // STEP 1 — Load the three ontologies once, to confirm they parse
        // correctly and report how many triples they contain in total.
        // ============================================================
        System.out.println("========================================================");
        System.out.println("  STEP 1: Loading ontologies");
        System.out.println("========================================================");

        OntModel ont = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC);
        synchronized (DIPLO_LOCK) {
            ont.read(Paths.get("diplodocus.owl.ttl").toUri().toString(), "TURTLE");
        }
        ont.read(Paths.get("mapping.owl.ttl").toUri().toString(),     "TURTLE");

        System.out.println("  Loaded " + ont.size() + " triples (TBox + ABox + mapping).");

        // ============================================================
        // STEP 2 — Start the background thread that invents new commands.
        // ============================================================
        Thread generatorThread = new Thread(
                DiploToNs3Mapper::runCommandGenerator,
                "diplo-command-generator");
        //generatorThread.setDaemon(true);
        //generatorThread.start();

        // ============================================================
        // STEP 3 — Run the event-driven pipeline: wait for diplodocus.owl.ttl
        // to change, and immediately SUBMIT (without waiting) Direction 1 for
        // whatever new command(s) that change introduced. Direction 2 for
        // each command runs later, automatically, whenever its own result
        // becomes available.
        // ============================================================
        System.out.println("\n#########################################################");
        System.out.println("  CO-SIMULATION PIPELINE (Phase I model check, then Phase II co-simulation)");
        System.out.println("#########################################################");

        Model ns3Model = RDFDataMgr.loadModel(
                Paths.get("ns3.owl.ttl").toUri().toString(),
                org.apache.jena.riot.Lang.TURTLE);

        PipelineState state = new PipelineState();
        state.ns3Model    = ns3Model;
        state.clsPacket   = ns3Model.getResource(NS3 + "Packet");
        state.clsSocket   = ns3Model.getResource(NS3 + "Socket");
        state.clsNsTime   = ns3Model.getResource(NS3 + "NsTimePoint");
        state.clsTransRes = ns3Model.getResource(NS3 + "TransferResult");
        state.propPktSz     = ns3Model.createProperty(NS3 + "PacketSize");
        state.propSentTh    = ns3Model.createProperty(NS3 + "sentThrough");
        state.propNsVal     = ns3Model.createProperty(NS3 + "nsValue");
        state.propNsLatency = ns3Model.createProperty(NS3 + "measuredLatencyNs");
        state.runnerV = new Ns3RunnerVisualSyncUDP(
                "/home/isso84/ns-3-dev",
                "/home/isso84/ns-3-dev/build/netanim"
        );
        state.transferIndex = new AtomicInteger(1);
        state.ns3NextId = new AtomicInteger(0);
        state.ns3Started = false;
        state.processedCmdUris = new HashSet<String>();
        state.successCount = new AtomicInteger(0);
        state.failureCount = new AtomicInteger(0);
        state.inFlightProcessing = new CopyOnWriteArrayList<CompletableFuture<Void>>();

        Path diploPath = Paths.get("diplodocus.owl.ttl").toAbsolutePath();
        Path diploDir  = diploPath.getParent();
        String diploFileName = diploPath.getFileName().toString();

        WatchService watchService = FileSystems.getDefault().newWatchService();
        diploDir.register(watchService,
                StandardWatchEventKinds.ENTRY_MODIFY,
                StandardWatchEventKinds.ENTRY_CREATE);

        System.out.println("\n  Watching " + diploPath + " for changes (event-driven, no fixed polling delay).");
        System.out.println("  Running for " + (TOTAL_DURATION_MS / 1000) + "s total. "
                + "The command generator will inject commands automatically "
                + "for the first " + (GENERATOR_DURATION_MS / 1000) + "s.");

        handleNewCommands(state);

        long loopEndTime = System.currentTimeMillis() + TOTAL_DURATION_MS;

        while (System.currentTimeMillis() < loopEndTime) {
            WatchKey key;
            try {
                key = watchService.poll(WATCH_POLL_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                break;
            }

            if (key == null) {
                continue;
            }

            boolean relevantChange = false;
            for (WatchEvent<?> event : key.pollEvents()) {
                Object context = event.context();
                if (context != null && context.toString().equals(diploFileName)) {
                    relevantChange = true;
                }
            }
            key.reset();

            if (relevantChange) {
                handleNewCommands(state);
            }
        }

        System.out.println("\n  [final pass] Running one last check for any unhandled command...");
        handleNewCommands(state);

        // --- Wait for any command whose result was still "in flight" (sent
        //     to NS-3, but not yet answered/processed) when the timed loop
        //     above ended. Without this, the JVM could exit (all remaining
        //     threads are daemon threads) before some already-submitted
        //     commands ever get their Direction 2 processing done.
        System.out.println("\n  Waiting up to " + FINAL_DRAIN_TIMEOUT_SECONDS
                + "s for any results still in flight...");
        try {
            CompletableFuture<?>[] remaining = state.inFlightProcessing.toArray(new CompletableFuture<?>[0]);
            if (remaining.length > 0) {
                CompletableFuture.allOf(remaining).get(FINAL_DRAIN_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            }
        } catch (Exception e) {
            System.out.println("  Some in-flight results did not complete in time: " + e.getMessage());
        }

        System.out.println("\n  Pipeline window ended.");
        System.out.println("  Commands detected      : " + state.processedCmdUris.size());
        System.out.println("  Successfully simulated  : " + state.successCount.get());
        System.out.println("  Failed / timed out      : " + state.failureCount.get());

        // ============================================================
        // STEP 4 — Open the NetAnim visualisation of everything that was
        // simulated, once the whole run is complete.
        // ============================================================
        // NetAnim disabled for now
        /*if (state.ns3Started) {
            state.runnerV.launchNetAnim("/tmp/java-bridge-sim.xml");
            System.out.println("NetAnim window should now be opening with the visual...");
        }*/

        // ============================================================
        // PHASE III -- After the simulation: requirement checking and
        // traceability with SPARQL over the results kept in the ontologies.
        // ============================================================
        if (!MODEL_REJECTED) runPhase3();

        /*if (state.ns3Started) {
            System.out.println("  Waiting for NS-3 to finish so the NetAnim file gets flushed...");
            state.runnerV.stopAndClose(); // force-terminate now that all results are drained
            Thread.sleep(30000); // brief grace period for the OS to finish writing the file
            state.runnerV.launchNetAnim("/tmp/java-bridge-sim.xml");
        }*/

        /*if (state.ns3Started) {
            System.out.println("  Waiting for NS-3 to terminate on its own so the NetAnim file gets flushed...");
            try {
                // Doit être PLUS GRAND que le Simulator::Stop(Seconds(120)) du .cc,
                // sinon on abandonne avant que NS-3 ait fini tout seul.
                boolean exited = state.runnerV.waitForNs3ToFinish(300);
                if (!exited) {
                    System.out.println("  WARNING: NS-3 didn't exit in time - forcing stop (file may be incomplete).");
                    state.runnerV.stopAndClose();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            state.runnerV.launchNetAnim("/tmp/java-bridge-sim.xml");
        }*/

        System.out.println("\n  DONE.");
    }

    // ============================================================
    //   PHASE III
    // ============================================================
    static final String SPARQL_PREFIXES =
          "PREFIX dip:  <" + DIP + ">\n"
        + "PREFIX ns3:  <" + NS3 + ">\n"
        + "PREFIX rdf:  <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n"
        + "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\n"
        + "PREFIX owl:  <http://www.w3.org/2002/07/owl#>\n"
        + "PREFIX xsd:  <http://www.w3.org/2001/XMLSchema#>\n";

    private static Model loadResults() {
        Model m = ModelFactory.createDefaultModel();
        synchronized (DIPLO_LOCK) {
            try {
                java.nio.channels.FileLock fl = lockDiploFile();
                try {
                    m.read(Paths.get("diplodocus.owl.ttl").toUri().toString(), "TURTLE");
                } finally { unlockDiploFile(fl); }
            } catch (Exception e) {
                System.out.println("  [Phase III] cannot read diplodocus.owl.ttl: " + e.getMessage());
            }
            m.read(Paths.get("ns3.owl.ttl").toUri().toString(), "TURTLE");
        }
        m.read(Paths.get("mapping.owl.ttl").toUri().toString(), "TURTLE");
        return m;
    }

    private static void runQuery(Model m, String body) {
        try (QueryExecution qe = QueryExecutionFactory.create(
                QueryFactory.create(SPARQL_PREFIXES + body), m)) {
            Query q = qe.getQuery();
            if (q.isSelectType())      ResultSetFormatter.out(System.out, qe.execSelect(), q);
            else if (q.isAskType())    System.out.println("  ASK -> " + qe.execAsk());
            else if (q.isConstructType() || q.isDescribeType()) {
                Model r = q.isConstructType() ? qe.execConstruct() : qe.execDescribe();
                RDFDataMgr.write(System.out, r, RDFFormat.TURTLE_PRETTY);
            }
        } catch (Exception e) {
            System.out.println("  [Phase III] query error: " + e.getMessage());
        }
    }

    private static void runPhase3() {
        System.out.println("\n########################################################");
        System.out.println("  PHASE III -- After the simulation: requirements and traceability (SPARQL)");
        System.out.println("########################################################");
        Model m = loadResults();
        System.out.println("  Results loaded: " + m.size() + " triples (diplodocus + ns3 + mapping).");

        System.out.println("\n  Enter your SPARQL queries on the simulation results");
        System.out.println("  (prefixes dip:, ns3:, rdf:, rdfs:, owl:, xsd: are predefined).");
        System.out.println("  Type a query on one or several lines, end it with a line containing only ';'.");
        System.out.println("  Type 'exit' to quit.");
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        StringBuilder q = new StringBuilder();
        try {
            System.out.print("sparql> ");
            String line;
            while ((line = in.readLine()) != null) {
                String t = line.trim();
                if (q.length() == 0 && t.equalsIgnoreCase("exit")) break;
                if (t.equals(";")) {
                    if (q.length() > 0) runQuery(m, q.toString());
                    q.setLength(0);
                    System.out.print("sparql> ");
                    continue;
                }
                q.append(line).append("\n");
            }
        } catch (IOException e) {
            System.out.println("  [Phase III] input error: " + e.getMessage());
        }
        System.out.println("  Phase III finished.");
    }

    /**
     * Groups together everything that needs to stay alive across successive
     * calls to handleNewCommands(): the in-memory NS-3 ontology model and its
     * class/property handles, the running NS-3 process manager, and the
     * bookkeeping needed to avoid simulating the same command twice or losing
     * track of results still in flight when the program is about to exit.
     */
    private static class PipelineState {
        Model ns3Model;
        Resource clsPacket, clsSocket, clsNsTime, clsTransRes;
        Property propPktSz, propSentTh, propNsVal, propNsLatency;
        Ns3RunnerVisualSyncUDP runnerV;
        AtomicInteger transferIndex;
        // Mirrors the runner's internal command-id counter (start() and every
        // sendCommandAsync() each consume exactly one id, in submission order),
        // so a command's id is known BEFORE it is submitted. Skipped
        // ReceiverNI commands never consume an id.
        AtomicInteger ns3NextId;
        boolean ns3Started;
        Set<String> processedCmdUris;
        AtomicInteger successCount;
        AtomicInteger failureCount;
        // Every command's end-to-end processing future (Direction 1 submission
        // through Direction 2 completion), so the program can wait for all of
        // them before exiting.
        CopyOnWriteArrayList<CompletableFuture<Void>> inFlightProcessing;

        // Filled in when a Receiver command is detected and skipped, keyed by
        // the receiver command name. Written by the main thread, read by
        // NS-3's reader thread, hence a concurrent map.
        Map<String, ReceiverInfo> receiverStartCycles =
                new java.util.concurrent.ConcurrentHashMap<String, ReceiverInfo>();

        static class ReceiverInfo {
            double startCycle;
            int    iter;
            ReceiverInfo(double sc, int i) { startCycle = sc; iter = i; }
        }

        // Per-sender iteration counters (1, 2, 3, ...), keyed by sender task
        // name. Only touched by the main thread, when a sender command is
        // submitted.
        Map<String, Integer> senderIterCounts = new HashMap<>();

        // Filled by the SEND result callback, read by the RECEIVE result
        // callback (both run one after the other on NS-3's reader thread).
        volatile double lastSendLatencyNs = 0;
        volatile int lastSenderEndCycle = 0;
        volatile boolean sendResultReady = false;
    }

    // ============================================================
    //   HELPERS: side-channel + ontology write-back for the receiver
    // ============================================================

    /** Appends "NET_DONE <taskName> <endCycle>" to the side-channel file read
     *  by the Diplodocus C++ simulator. */
    /*private static void writeSideChannel(String taskName, int endCycle) {
        synchronized (SIDE_CHANNEL_LOCK) {
            try (FileWriter fw = new FileWriter(SIDE_CHANNEL_PATH, true)) {
                fw.write("NET_DONE " + taskName + " " + endCycle + "\n");
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        }
        System.out.println("  [side-channel] wrote NET_DONE " + taskName + " " + endCycle);
    }*/
    
    /** Appends a side-channel line with an EXPLICIT per-task
     *  iteration number, so the line "NET_DONE <task> <endCycle> <iter>"
     *  matches the iteration the C++ runner is waiting for. */
    private static void writeSideChannel(String taskName, int endCycle, int iter) {
        System.out.println("[DEBUG-SIDECHANNEL] Writing: NET_DONE " + taskName + " " + endCycle + " " + iter);
        synchronized (SIDE_CHANNEL_LOCK) {
            try (FileWriter fw = new FileWriter(
                    "/home/isso84/TTool-ns3/simulators/c++2/net_done.sidechannel", true)) {
                fw.write("NET_DONE " + taskName + " " + endCycle
                         + " " + iter + "\n");
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        }
        System.out.println("  [side-channel] wrote NET_DONE "
                + taskName + " " + endCycle + " iter=" + iter);
    }

    /** Finds the ReceiverNI start cycle for ONE specific iteration in the
     *  receiver_start file (lines "<startCycle> <iteration>"). Returns 0 if
     *  the file or the iteration is not found. */
    /*private static double readReceiverStartCycle(int currentSenderIter) {
        double result = 0;
        try (BufferedReader br = new BufferedReader(
                new FileReader(RECEIVER_START_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split("\\s+");
                if (parts.length >= 2) {
                    double sc = Double.parseDouble(parts[0]);
                    int iter = Integer.parseInt(parts[1]);
                    // Match iteration number with current sender iteration
                    if (iter == currentSenderIter) {
                        result = sc;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            result = 0;
        }
        return result;
    }*/
    
    
    /** Waits until the ReceiverNI start cycle for iteration `currentSenderIter`
     *  appears in the receiver_start file (lines "<startCycle> <iteration>").
     *  Polls every 50 ms, for up to 10 s. Returns 0 if it never appears. */
    private static double readReceiverStartCycle(String receiverStartFile,
                                                 int currentSenderIter,
                                                 long timeoutMs) {
        // Wait for the receiver's iter N to write its startCycle
        // (timeoutMs = 0 -> a single attempt, no waiting)
        double receiverStartCycle = 0;
        long waitStart = System.currentTimeMillis();
        boolean found = false;

        do {
            try (BufferedReader br = new BufferedReader(
                    new FileReader(receiverStartFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length >= 2) {
                        double sc = Double.parseDouble(parts[0]);
                        int iter = Integer.parseInt(parts[1]);
                        if (iter == currentSenderIter) {
                            receiverStartCycle = sc;
                            found = true;
                            break;
                        }
                    }
                }
            } catch (Exception e) { /* ignore: file missing or half-written line */ }

            if (!found && timeoutMs > 0) {
                try {
                    Thread.sleep(50); // wait 50ms and retry
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        } while (!found && (System.currentTimeMillis() - waitStart) < timeoutMs);

        if (!found) {
            System.out.println("  [WARNING] Receiver startCycle for iter="
                + currentSenderIter + " not found in " + receiverStartFile + ", using 0");
        }
        return receiverStartCycle;
    }
    
    
    
    
    
    
    
    
    
    

    /** Writes a dip:endsAtCycle individual for the given command back into
     *  diplodocus.owl.ttl (same pattern as the PART D backpropagation). */
    private static void updateOntologyEndCycle(PipelineState state,
            String cmdLocalName, int endCycle, double f) {
        String endCycleName = cmdLocalName + "_EndCycle";
        synchronized (DIPLO_LOCK) {
            java.nio.channels.FileLock fl = null;
            try {
                fl = lockDiploFile();
                Model diploModel = RDFDataMgr.loadModel(
                        Paths.get("diplodocus.owl.ttl").toUri().toString(),
                        org.apache.jena.riot.Lang.TURTLE);

                Resource clsCycleTime = diploModel.getResource(DIP + "CycleTimePoint");
                Property propCycleVal = diploModel.createProperty(DIP + "cycleValue");
                Property propEndsAt   = diploModel.createProperty(DIP + "endsAtCycle");

                Resource endCycleInd = diploModel.createResource(DIP + endCycleName);
                endCycleInd.addProperty(RDF.type, clsCycleTime);
                endCycleInd.addProperty(RDFS.comment, diploModel.createLiteral(
                        "End cycle of " + cmdLocalName + " computed from the NS-3 RECEIVE latency"
                        + " (masterClockHz=" + f + ")  =>  endCycle = " + endCycle));
                endCycleInd.addLiteral(propCycleVal,
                        diploModel.createTypedLiteral(String.valueOf((double) endCycle), XSDDatatype.XSDdouble));

                Resource cmdRes = diploModel.getResource(DIP + cmdLocalName);
                cmdRes.addProperty(propEndsAt, endCycleInd);

                try (FileOutputStream out = new FileOutputStream("diplodocus.owl.ttl")) {
                    RDFDataMgr.write(out, diploModel, RDFFormat.TURTLE_PRETTY);
                }
            } catch (Exception e) {
                System.out.println("  ERROR updating ontology for " + cmdLocalName + ": " + e.getMessage());
                e.printStackTrace();
                return;
            } finally { unlockDiploFile(fl); }
        }
        System.out.println("  Linked " + cmdLocalName + " --dip:endsAtCycle--> " + endCycleName);
        System.out.println("  diplodocus.owl.ttl updated.");
    }

    // ============================================================
    //   START-UP MODEL CHECK (branch 1 of handleNewCommands)
    // ============================================================
    /** Reads the TTool model, adds its NI channels to diplodocus.owl.ttl,
     *  runs the reasoner and writes the verdict for Diplodocus. */
    private static void runModelCheck(String xmlPath) {
        System.out.println("\n########################################################");
        System.out.println("  PHASE I -- Before the simulation: start-up model check (before cycle 0)");
        System.out.println("########################################################");
        try {
            ModelChecker mc = new ModelChecker(xmlPath);
            mc.parse();
            Model individuals = mc.toRdf();

            Model tbox, withIndividuals;
            synchronized (DIPLO_LOCK) {
                java.nio.channels.FileLock fl = lockDiploFile();
                try {
                    tbox = RDFDataMgr.loadModel(
                            Paths.get("diplodocus.owl.ttl").toUri().toString(),
                            org.apache.jena.riot.Lang.TURTLE);
                    withIndividuals = ModelFactory.createDefaultModel();
                    withIndividuals.setNsPrefixes(tbox.getNsPrefixMap());
                    withIndividuals.add(tbox);
                    withIndividuals.add(individuals);
                    try (FileOutputStream out = new FileOutputStream("diplodocus.owl.ttl")) {
                        RDFDataMgr.write(out, withIndividuals, RDFFormat.TURTLE_PRETTY);
                    }
                } finally { unlockDiploFile(fl); }
            }
            System.out.println("  [model-check] " + individuals.size()
                    + " triples added to diplodocus.owl.ttl (channels, NI tasks, networks, buses).");

            mc.reason(withIndividuals, tbox);
            mc.writeResult();
            MODEL_REJECTED = !mc.consistent;
            NB_TRANSPORT.putAll(mc.transportFields);
            for (Map.Entry<String, String> e : NB_TRANSPORT.entrySet())
                System.out.println("  [model-check] NS3 configuration for " + e.getKey() + ": " + e.getValue());
        } catch (Exception e) {
            System.out.println("  [model-check] ERROR: " + e.getMessage());
            e.printStackTrace();
            ModelChecker.writeError("model check failed: " + e.getMessage());
        }
        System.out.println("########################################################\n");
        if (!MODEL_REJECTED) {
            System.out.println("########################################################");
            System.out.println("  PHASE II -- During the simulation: Diplodocus <-> NS-3 co-simulation");
            System.out.println("########################################################\n");
        }
    }

    // ============================================================
    //   EVENT HANDLER: called every time diplodocus.owl.ttl changes
    // ============================================================
    /**
     * Looks for dip:WriteChannelCommand individuals that haven't been
     * simulated yet, sorts them by their creation order, and SUBMITS each
     * one to NS-3 in that order, WITHOUT waiting for a result before moving
     * on to the next - several commands can be "in flight" inside NS-3 at
     * once. For each command, Direction 2 is attached as a continuation that
     * runs automatically as soon as - and only when - that specific
     * command's own result becomes available, however long that takes and
     * regardless of what order different commands' results arrive in.
     *
     * ReceiverNI commands are filtered out (not sent to NS-3): they are
     * handled through the RECEIVE result of the SenderNI command.
     */
    private static void handleNewCommands(PipelineState state) throws IOException {
        if (MODEL_REJECTED) return;   // model refused by the start-up check: nothing to simulate

        OntModel ontLoop = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC);
        synchronized (DIPLO_LOCK) {
            java.nio.channels.FileLock fl = lockDiploFile();
            try {
                ontLoop.read(Paths.get("diplodocus.owl.ttl").toUri().toString(), "TURTLE");
            } finally { unlockDiploFile(fl); }
            ontLoop.read(Paths.get("ns3.owl.ttl").toUri().toString(),     "TURTLE");
        }
        ontLoop.read(Paths.get("mapping.owl.ttl").toUri().toString(), "TURTLE");

        OntClass dipWriteCmdClassLoop = ontLoop.getOntClass(DIP + "WriteChannelCommand");
        OntClass dipNetTaskClassLoop  = ontLoop.getOntClass(DIP + "NetTask");
        OntClass ns3PacketClassLoop   = ontLoop.getOntClass(NS3 + "Packet");
        OntClass ns3SocketClassLoop   = ontLoop.getOntClass(NS3 + "Socket");
        OntClass ns3NsTimeClassLoop   = ontLoop.getOntClass(NS3 + "NsTimePoint");

        OntProperty dipHasDataQtyLoop  = ontLoop.getOntProperty(DIP + "hasDataQuantity");
        OntProperty dipStartsAtLoop    = ontLoop.getOntProperty(DIP + "startsAtCycle");
        OntProperty dipDataSizeLoop    = ontLoop.getOntProperty(DIP + "DataSize");
        OntProperty dipCycleValueLoop  = ontLoop.getOntProperty(DIP + "cycleValue");
        OntProperty dipMasterClockLoop = ontLoop.getOntProperty(DIP + "FrequencyHz");
        OntProperty ns3PacketSizeLoop  = ontLoop.getOntProperty(NS3 + "PacketSize");
        OntProperty ns3NsValueLoop     = ontLoop.getOntProperty(NS3 + "nsValue");
        OntProperty dipSeqNumLoop      = ontLoop.getOntProperty(DIP + "commandSequenceNumber");

        // ============================================================
        // BRANCH 1 - start-up model check (Diplodocus writes ONE
        // dip:ModelCheckRequest before cycle 0). Handled here, apart
        // from the transfer commands.
        // ============================================================
        // Read the RAW file (no reasoner, no class declaration needed) to find
        // a ModelCheckRequest written by Diplodocus.
        Model raw;
        synchronized (DIPLO_LOCK) {
            java.nio.channels.FileLock flr = lockDiploFile();
            try {
                raw = RDFDataMgr.loadModel(Paths.get("diplodocus.owl.ttl").toUri().toString(),
                                           org.apache.jena.riot.Lang.TURTLE);
            } finally { unlockDiploFile(flr); }
        }
        Resource reqClass = raw.createResource(DIP + "ModelCheckRequest");
        Property reqPath  = raw.createProperty(DIP + "modelPath");
        boolean checked = false;
        ResIterator reqs = raw.listSubjectsWithProperty(RDF.type, reqClass);
        while (reqs.hasNext()) {
            Resource req = reqs.next();
            if (state.processedCmdUris.contains(req.getURI())) continue;
            state.processedCmdUris.add(req.getURI());
            System.out.println("  [model-check] request found: " + req.getLocalName());
            Statement mp = req.getProperty(reqPath);
            runModelCheck(mp == null ? "" : mp.getString());
            checked = true;
        }
        if (checked) return;   // the check rewrote diplodocus.owl.ttl: commands come with the next event

        // ============================================================
        // BRANCH 2 - transfer commands (unchanged pipeline)
        // ============================================================
        List<Individual> allCmds      = listIndividuals(ontLoop, dipWriteCmdClassLoop);
        List<Individual> netTasksLoop = listIndividuals(ontLoop, dipNetTaskClassLoop);

        List<Individual> newCmds = new ArrayList<Individual>();
        for (Individual c : allCmds) {
            if (!state.processedCmdUris.contains(c.getURI())) {
                newCmds.add(c);
            }
        }

        if (newCmds.isEmpty()) {
            return;
        }

        // --- Sort by creation order (dip:commandSequenceNumber), so commands
        //     are always SUBMITTED to NS-3 in the order they were actually
        //     created. Their RESULTS may still complete in a different order
        //     once concurrency is in play - that is expected and handled.
        final OntProperty seqPropFinal = dipSeqNumLoop;
        Collections.sort(newCmds, new Comparator<Individual>() {
            @Override
            public int compare(Individual a, Individual b) {
                long seqA = readSequenceNumber(a, seqPropFinal);
                long seqB = readSequenceNumber(b, seqPropFinal);
                return Long.compare(seqA, seqB);
            }
        });

        System.out.println("\n  [event] diplodocus.owl.ttl changed - found " + newCmds.size()
                + " new command(s) (submitting in creation order, without waiting for results).");

        for (Individual cmd : newCmds) {
            state.processedCmdUris.add(cmd.getURI());
            final String cmdLocalName = cmd.getLocalName();
            System.out.println("\n  --- Mapping command: " + cmdLocalName);
            System.out.println("[DEBUG] Processing command: " + cmdLocalName);
            System.out.println("[DEBUG] task=" + taskOf(cmdLocalName)
                + " isSender=" + NB_SENDER_TO_RECEIVER.containsKey(taskOf(cmdLocalName))
                + " isReceiver=" + NB_RECEIVER_TO_SENDER.containsKey(taskOf(cmdLocalName)));

            // ------------------------------------------------------------
            // FILTER: skip ReceiverNI command - it is handled as part of the
            // SenderNI result (the RECEIVE latency). Only remember its start
            // cycle and name for later; do NOT send it to NS-3.
            // ------------------------------------------------------------
            if (NB_RECEIVER_TO_SENDER.containsKey(taskOf(cmdLocalName))) {
                System.out.println("  [filter] Skipping " + cmdLocalName
                        + " - will be handled by its paired Sender result.");

                double receiverStartCycle = 0;
                Individual startCycleInd = getLinkedIndividual(ontLoop, cmd, dipStartsAtLoop);
                if (startCycleInd != null && startCycleInd.getProperty(dipCycleValueLoop) != null) {
                    receiverStartCycle =
                            startCycleInd.getProperty(dipCycleValueLoop).getDouble();
                } else {
                    System.out.println("  [filter] WARNING: no start cycle found for "
                            + cmdLocalName + " - using 0.");
                }

                // Iteration number, taken from "..._iterN_..." when present.
                int currentIter = 0;
                java.util.regex.Matcher im =
                        java.util.regex.Pattern.compile("_iter(\\d+)").matcher(cmdLocalName);
                if (im.find()) {
                    currentIter = Integer.parseInt(im.group(1));
                }

                // Store per-receiver startCycle in a map keyed by receiver name
                state.receiverStartCycles.put(cmdLocalName,
                        new PipelineState.ReceiverInfo(receiverStartCycle, currentIter));
                System.out.println("  [filter] Stored receiver startCycle=" + receiverStartCycle
                        + " iter=" + currentIter + " for " + cmdLocalName);
                continue; // do not send to NS-3
            }

            // ------------------------------------------------------------
            // Normal processing for the SenderNI command (Parts A, B, C).
            // ------------------------------------------------------------
            Individual dataQtyInd = getLinkedIndividual(ontLoop, cmd, dipHasDataQtyLoop);
            Individual cycleInd   = getLinkedIndividual(ontLoop, cmd, dipStartsAtLoop);
            // Clock reference: the first NetTask that has a master clock
            // (NI tasks added by the model check have no clock of their own)
            Individual netTaskInd = null;
            for (Individual nt : netTasksLoop) {
                if (nt.getProperty(dipMasterClockLoop) != null) { netTaskInd = nt; break; }
            }

            if (dataQtyInd == null || cycleInd == null || netTaskInd == null) {
                System.out.println("  SKIP: missing linked individual.");
                state.failureCount.incrementAndGet();
                continue;
            }

            // PART B: dip:DataSize and ns3:PacketSize are declared
            // equivalent properties, so the reasoner already lets us read the
            // SAME value from the individual using either property name.
            int packetSizeVal;
            Statement ns3Stmt = dataQtyInd.getProperty(ns3PacketSizeLoop);
            if (ns3Stmt != null) {
                packetSizeVal = ns3Stmt.getInt();
                System.out.println("  [PART B - equivalentProperty]  dip:DataSize = ns3:PacketSize = "
                        + packetSizeVal + " bytes  (inferred by OWL reasoner)");
            } else {
                packetSizeVal = dataQtyInd.getProperty(dipDataSizeLoop).getInt();
                System.out.println("  [PART B - direct read]  dip:DataSize = " + packetSizeVal + " bytes");
            }

            System.out.println("  [PART A]  " + dataQtyInd.getLocalName() + " -> ns3:Packet? "
                    + dataQtyInd.hasOntClass(ns3PacketClassLoop, false));
            System.out.println("  [PART A]  " + netTaskInd.getLocalName() + " -> ns3:Socket? "
                    + netTaskInd.hasOntClass(ns3SocketClassLoop, false));
            System.out.println("  [PART A]  " + cycleInd.getLocalName() + " -> ns3:NsTimePoint? "
                    + cycleInd.hasOntClass(ns3NsTimeClassLoop, false));

            // PART C: the reasoner has already computed nsValue via the SWRL
            // rule in mapping.owl.ttl - we simply read the result here.
            final int    cycleVal      = cycleInd.getProperty(dipCycleValueLoop).getInt();
            final double masterClockHz = netTaskInd.getProperty(dipMasterClockLoop).getDouble();
            final double nsValue       = cycleInd.getProperty(ns3NsValueLoop).getDouble();

            System.out.println("  [PART C - SWRL cycle->ns]  cycleValue=" + cycleVal
                    + "  f=" + masterClockHz + " Hz  -->  nsValue=" + nsValue + " ns");

            final String packetName = dataQtyInd.getLocalName() + "_Packet";
            final String socketName = netTaskInd.getLocalName() + "_Socket";
            final String nsTimeName = cycleInd.getLocalName()   + "_NsTimePoint";
            final String trResName  = "_TransferResult" + state.transferIndex.getAndIncrement();
            final String dataQtyLocalName = dataQtyInd.getLocalName();
            final String netTaskLocalName = netTaskInd.getLocalName();
            final String cycleLocalName   = cycleInd.getLocalName();

            // Only the SenderNI command yields a RECEIVE result as well.
            final boolean isSender = NB_SENDER_TO_RECEIVER.containsKey(taskOf(cmdLocalName));

            // Derive the sender task name and its paired receiver names.
            // "cmd_App1__Sender1NI_iter1_WriteCmd" -> sender task "App1__Sender1NI"
            // paired receiver task = "App1__Receiver1NI"
            String senderTaskNameTmp = cmdLocalName;
            if (senderTaskNameTmp.startsWith("cmd_")) {
                senderTaskNameTmp = senderTaskNameTmp.substring(4);
            }
            senderTaskNameTmp = senderTaskNameTmp.replaceAll("(_iter\\d+)?_WriteCmd$", "");
            final String senderTaskName = senderTaskNameTmp;
            final String appPrefix = senderTaskName.contains("__")
                    ? senderTaskName.substring(0, senderTaskName.lastIndexOf("__") + 2) : "";
            final String pairedReceiverTaskName =
                    appPrefix + NB_SENDER_TO_RECEIVER.getOrDefault(shortName(senderTaskName), "");
            final String pairedReceiverCmdName  = cmdLocalName.replace(senderTaskName, pairedReceiverTaskName);

            if (isSender) {
                final String rcvStartFileDbg = RECEIVER_START_FILE + "."
                    + "cmd_" + pairedReceiverTaskName;
                System.out.println("[DEBUG] pairedReceiverTaskName=" + pairedReceiverTaskName);
                System.out.println("[DEBUG] rcvStartFile=" + rcvStartFileDbg);
                System.out.println("[DEBUG] receiverStartCycle=" + state.receiverStartCycles.get(pairedReceiverTaskName + "_cmd"));
            }

            // Iteration number of this SenderNI command (1, 2, 3, ...).
            // Per-sender: Sender1NI and Sender2NI each count 1, 2, 3, ... independently.
            // (senderTaskName was extracted above from cmdLocalName, e.g.
            //  "cmd_App1__Sender2NI_iter1_WriteCmd" -> "App1__Sender2NI")
            int senderIterTmp = 0;
            if (isSender) {
                state.senderIterCounts.putIfAbsent(senderTaskName, 0);
                senderIterTmp = state.senderIterCounts.get(senderTaskName) + 1;
                state.senderIterCounts.put(senderTaskName, senderIterTmp);
            }
            final int currentSenderIter = senderIterTmp;
            // Sender1NI (NI0) -> node0 to node1 ; Sender2NI (NI1) -> node1 to node0
            final int direction = NB_SENDER_NODE.getOrDefault(shortName(senderTaskName), 0);
            // Transport chosen by the start-up model check ("" = default UDP, no loss)
            final String transportFields = NB_TRANSPORT.getOrDefault(shortName(senderTaskName), "");
            System.out.println("[DEBUG] " + senderTaskName + " transport fields='" + transportFields + "'");
            System.out.println("[DEBUG] " + senderTaskName + " direction=" + direction);

            // --- Reserve the NS-3 command id (mirrors the runner's own
            //     counter: one id per start()/sendCommandAsync() call).
            final int id = state.ns3NextId.getAndIncrement();

            // --- Register the RECEIVE future BEFORE submitting the command,
            //     so NS-3's receive result can never arrive before the future
            //     exists.
            final CompletableFuture<Double> receiveFuture =
                    isSender ? state.runnerV.getReceiveFuture(id) : null;

            // --- Submit the command to NS-3 WITHOUT waiting for the result.
            //     The very first command starts a brand-new NS-3 process;
            //     every following command is sent to that SAME already-running
            //     process instead of starting a new one.
            CompletableFuture<Double> resultFuture;
            try {
                if (!state.ns3Started) {
                    resultFuture = state.runnerV.start(nsValue, packetSizeVal, direction, transportFields);
                    state.ns3Started = true;
                } else {
                    resultFuture = state.runnerV.sendCommandAsync(nsValue, packetSizeVal, direction, transportFields);
                }
            } catch (IOException e) {
                System.out.println("  FAILED to submit " + cmdLocalName + " to NS-3: " + e.getMessage());
                state.failureCount.incrementAndGet();
                if (receiveFuture != null) {
                    receiveFuture.cancel(false);
                }
                continue;
            }

            // syncronisation problem
            // Wait for NS3 process to be ready (it needs ~5-6s to start)
               /*if (!state.ns3Started) {
                   System.out.println("  [bridge] Waiting for NS3 to be ready...");
                   try { Thread.sleep(7000); } catch (InterruptedException e) {}
                   System.out.println("  [bridge] NS3 should be ready now.");
                   resultFuture = state.runnerV.start(nsValue, packetSizeVal);
                   state.ns3Started = true;
               } else {
                   resultFuture = state.runnerV.sendCommandAsync(packetSizeVal);
               }*/

            // Fail this ONE command's own future if NS-3 takes too long to
            // answer - this never affects any other command, since each has
            // its own independent future.
            resultFuture = resultFuture.orTimeout(NS3_RESULT_TIMEOUT_SECONDS, TimeUnit.SECONDS);

            System.out.println("  Submitted " + cmdLocalName + " to NS-3 (packetSize=" + packetSizeVal
                    + ", id=" + id + ") - moving on without waiting for its result.");

            // ------------------------------------------------------------
            //   SEND result -> DIRECTION 2 (ns3.owl.ttl + endsAtCycle for the
            //   sender command + SenderNI side-channel). Runs automatically,
            //   asynchronously, whenever THIS command's own result becomes
            //   available - see the class comment "THREADING DETAILS" for why
            //   this is safe without extra locks around ns3Model / ns3.owl.ttl.
            // ------------------------------------------------------------
            CompletableFuture<Void> processing = resultFuture.handle((measuredLatencyNs, ex) -> {
                if (ex != null) {
                    System.out.println("\n  FAILED: NS-3 did not answer for " + cmdLocalName
                            + " within " + NS3_RESULT_TIMEOUT_SECONDS + "s (" + ex.getMessage() + ").");
                    state.failureCount.incrementAndGet();
                    return null;
                }

                try {
                    state.successCount.incrementAndGet();
                    System.out.println("\n  --- NS-3 result ready for: " + cmdLocalName);
                    System.out.println("  Measured latency (ns): " + measuredLatencyNs);

                    // --- Create the NS-3 side of this command as new individuals.
                    // ns3Model / ns3.owl.ttl are shared by the result threads:
                    // modified and written under DIPLO_LOCK.
                    synchronized (DIPLO_LOCK) {
                    Resource pkt = state.ns3Model.createResource(NS3 + packetName);
                    pkt.addProperty(RDF.type, state.clsPacket);
                    pkt.addProperty(RDFS.comment, state.ns3Model.createLiteral(
                            "Mapped from dip:" + dataQtyLocalName
                            + " [PART A: equivalentClass, PART B: equivalentProperty]"));
                    pkt.addLiteral(state.propPktSz, packetSizeVal);

                    Resource sock = state.ns3Model.createResource(NS3 + socketName);
                    sock.addProperty(RDF.type, state.clsSocket);
                    sock.addProperty(RDFS.comment, state.ns3Model.createLiteral(
                            "Mapped from dip:" + netTaskLocalName
                            + " [PART A: equivalentClass dip:NetTask=ns3:Socket]"));
                    pkt.addProperty(state.propSentTh, sock);

                    Resource nst = state.ns3Model.createResource(NS3 + nsTimeName);
                    nst.addProperty(RDF.type, state.clsNsTime);
                    nst.addProperty(RDFS.comment, state.ns3Model.createLiteral(
                            "Mapped from dip:" + cycleLocalName
                            + " [PART C: nsValue = " + cycleVal
                            + " * (1e9 / " + masterClockHz + ") = " + nsValue + " ns]"));
                    nst.addLiteral(state.propNsVal, nsValue);

                    Resource trans = state.ns3Model.createResource(NS3 + trResName);
                    trans.addProperty(RDF.type, state.clsTransRes);
                    trans.addProperty(RDFS.comment, state.ns3Model.createLiteral(
                            "Created by NS3 to store the simulation result, for dip:" + cmdLocalName));
                    trans.addLiteral(state.propNsLatency, measuredLatencyNs);
                    // link the result to the Diplodocus command it belongs to (used in Phase III)
                    trans.addProperty(state.ns3Model.createProperty(NS3 + "resultOf"),
                            state.ns3Model.createResource(DIP + cmdLocalName));

                    System.out.println("  Created -> " + packetName + ", " + socketName
                            + ", " + nsTimeName + ", " + trResName);

                    try (FileOutputStream out = new FileOutputStream("ns3.owl.ttl")) {
                        RDFDataMgr.write(out, state.ns3Model, RDFFormat.TURTLE_PRETTY);
                    }
                    }   // end synchronized (DIPLO_LOCK) for ns3Model / ns3.owl.ttl
                    System.out.println("  ns3.owl.ttl updated.");

                    // --- DIRECTION 2: NS-3 -> Diplodocus, for this command only.
                    System.out.println("  --- Backpropagating result: " + trResName);

                    OntModel ont2 = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC);
                    synchronized (DIPLO_LOCK) {
                        java.nio.channels.FileLock fl = lockDiploFile();
                        try {
                            ont2.read(Paths.get("diplodocus.owl.ttl").toUri().toString(), "TURTLE");
                        } finally { unlockDiploFile(fl); }
                        ont2.read(Paths.get("ns3.owl.ttl").toUri().toString(),     "TURTLE");
                    }
                    ont2.read(Paths.get("mapping.owl.ttl").toUri().toString(), "TURTLE");

                    OntProperty dipCycleValueProp2 = ont2.getOntProperty(DIP + "cycleValue");
                    Individual resultInd = ont2.getIndividual(NS3 + trResName);

                    // PART D: the reasoner has already computed delay_cycles for
                    // this result via the SWRL rule in mapping.owl.ttl.
                    double delayCycles = resultInd.getProperty(dipCycleValueProp2).getDouble();
                    int    endCycle    = cycleVal + (int) Math.round(delayCycles);

                    System.out.println("  [DEBUG-SEND] measuredLatencyNs=" + measuredLatencyNs);
                    System.out.println("  [DEBUG-SEND] cycleVal=" + cycleVal);
                    System.out.println("  [DEBUG-SEND] endCycle=" + endCycle);
                    System.out.println("  [DEBUG-SEND] masterClockHz=" + masterClockHz);

                    System.out.println("  [PART D - SWRL inverse ns->cycle]  delay_cycles = "
                            + measuredLatencyNs + " * (" + masterClockHz + " / 1e9) = " + delayCycles);
                    System.out.println("  [PART D - SWRL inverse ns->cycle]  endCycle = " + cycleVal
                            + " + " + (int) Math.round(delayCycles) + " = " + endCycle);

                    String endCycleName = trResName + "_EndCycle";

                    synchronized (DIPLO_LOCK) {
                        java.nio.channels.FileLock fl = lockDiploFile();
                        try {
                        Model diploModel = RDFDataMgr.loadModel(
                                Paths.get("diplodocus.owl.ttl").toUri().toString(),
                                org.apache.jena.riot.Lang.TURTLE);

                        Resource clsCycleTime = diploModel.getResource(DIP + "CycleTimePoint");
                        Property propCycleVal = diploModel.createProperty(DIP + "cycleValue");
                        Property propEndsAt   = diploModel.createProperty(DIP + "endsAtCycle");

                        Resource endCycleInd = diploModel.createResource(DIP + endCycleName);
                        endCycleInd.addProperty(RDF.type, clsCycleTime);
                        endCycleInd.addProperty(RDFS.comment, diploModel.createLiteral(
                                "End cycle computed from ns3:" + trResName
                                + " [PART D: delay_cycles = " + measuredLatencyNs
                                + " * (" + masterClockHz + " / 1e9) = " + delayCycles
                                + "  =>  endCycle = " + cycleVal
                                + " + " + (int) Math.round(delayCycles)
                                + " = " + endCycle + "]"));

                        // dip:cycleValue has range xsd:double - written as an
                        // explicitly typed xsd:double literal holding a whole
                        // number (e.g. 2371.0).
                        endCycleInd.addLiteral(propCycleVal,
                                diploModel.createTypedLiteral(String.valueOf((double) endCycle), XSDDatatype.XSDdouble));

                        Resource cmdRes = diploModel.getResource(DIP + cmdLocalName);
                        cmdRes.addProperty(propEndsAt, endCycleInd);

                        try (FileOutputStream out = new FileOutputStream("diplodocus.owl.ttl")) {
                            RDFDataMgr.write(out, diploModel, RDFFormat.TURTLE_PRETTY);
                        }
                        } finally { unlockDiploFile(fl); }
                    }

                    System.out.println("  Linked " + cmdLocalName
                            + " --dip:endsAtCycle--> " + endCycleName);
                    System.out.println("  Created -> " + endCycleName + " with dip:cycleValue = " + endCycle);
                    System.out.println("  diplodocus.owl.ttl updated.");

                    // ---------- side-channel for Diplodocus (C++ simulator) ----------
                    // SEND result -> SenderNI. (The ontology endsAtCycle for
                    // the sender was just written above by PART D.)
                    System.out.println("  [side-channel] writing NET_DONE " + senderTaskName
                            + " " + endCycle + " iter=" + currentSenderIter);
                    // Side-channel carries the DURATION measured by NS3 (cycles);
                    // Diplodocus places it after the real start of the NET transaction.
                    writeSideChannel(senderTaskName, (int) Math.round(delayCycles), currentSenderIter);
                    // -----------------------------------------------------------------

                    // --- RECEIVE result processing happens HERE, inside the send callback,
                    //     so senderEndCycle and sendLatencyNs are captured as final locals.
                    //     This eliminates all race conditions with shared mutable state.
                    if (isSender && receiveFuture != null) {
                        final int    capturedSenderEndCycle  = endCycle;
                        final double capturedSendLatencyNs   = measuredLatencyNs;
                        final int    capturedSenderIter      = currentSenderIter;
                        final String capturedReceiverCmdName = pairedReceiverCmdName;
                        final String capturedReceiverTaskName = pairedReceiverTaskName;

                        CompletableFuture<Double> rf =
                            receiveFuture.orTimeout(NS3_RESULT_TIMEOUT_SECONDS, TimeUnit.SECONDS);

                        CompletableFuture<Void> receiveProcessing = rf.handle((receiveLatencyNs, rex) -> {
                            if (rex != null) {
                                System.out.println("\n  FAILED: NS-3 RECEIVE latency for "
                                    + cmdLocalName + ": " + rex.getMessage());
                                return null;
                            }
                            System.out.println("\n  --- NS-3 RECEIVE result for: " + cmdLocalName);
                            System.out.println("  Measured receive latency (ns): " + receiveLatencyNs);

                            double propagationNs     = receiveLatencyNs - capturedSendLatencyNs;
                            double propagationCycles = propagationNs * (masterClockHz / 1e9);
                            int    rcvEndCycle       = (int)(capturedSenderEndCycle + propagationCycles);

                            System.out.println("  [DEBUG-RECV] receiveLatencyNs=" + receiveLatencyNs);
                            System.out.println("  [DEBUG-RECV] capturedSendLatencyNs=" + capturedSendLatencyNs);
                            System.out.println("  [DEBUG-RECV] capturedSenderEndCycle=" + capturedSenderEndCycle);
                            System.out.println("  [DEBUG-RECV] propagationNs=" + propagationNs);
                            System.out.println("  [DEBUG-RECV] propagationCycles=" + propagationCycles);
                            System.out.println("  [DEBUG-RECV] rcvEndCycle=" + rcvEndCycle);

                            // Read receiver startCycle from its per-receiver file
                            // (single attempt, no waiting: the reader thread must not block).
                            String rcvStartFile = RECEIVER_START_FILE + "."
                                + "cmd_" + capturedReceiverTaskName;
                            double rcvStartCycle = readReceiverStartCycle(
                                    rcvStartFile, capturedSenderIter, 0);
                            System.out.println("  [DEBUG-RECV] receiver startCycle (from "
                                + rcvStartFile + ") = " + rcvStartCycle);

                            System.out.println("  [side-channel] NET_DONE " + capturedReceiverTaskName
                                + " " + rcvEndCycle + " iter=" + capturedSenderIter
                                + "  (senderEndCycle=" + capturedSenderEndCycle
                                + ", propagationNs=" + propagationNs
                                + ", propagationCycles=" + propagationCycles + ")");
                            // Receive duration = send time + propagation (measured by NS3)
                            int rcvDurationCycles = (int) Math.round(receiveLatencyNs * (masterClockHz / 1e9));
                            System.out.println("  [DEBUG-RECV] rcvDurationCycles=" + rcvDurationCycles);
                            writeSideChannel(capturedReceiverTaskName, rcvDurationCycles, capturedSenderIter);

                            // keep the end-to-end latency with the result (used in Phase III)
                            try {
                                synchronized (DIPLO_LOCK) {
                                    state.ns3Model.getResource(NS3 + trResName).addLiteral(
                                            state.ns3Model.createProperty(NS3 + "receiveLatencyNs"),
                                            receiveLatencyNs.doubleValue());
                                    try (FileOutputStream out = new FileOutputStream("ns3.owl.ttl")) {
                                        RDFDataMgr.write(out, state.ns3Model, RDFFormat.TURTLE_PRETTY);
                                    }
                                }
                            } catch (IOException ioe) {
                                System.out.println("  [Phase III data] cannot write receive latency: " + ioe.getMessage());
                            }

                            // Only if that receiver command exists in the ontology.
                            if (state.receiverStartCycles.containsKey(capturedReceiverCmdName)) {
                                updateOntologyEndCycle(state, capturedReceiverCmdName,
                                                       rcvEndCycle, masterClockHz);
                            }
                            return null;
                        });
                        state.inFlightProcessing.add(receiveProcessing);
                    }

                } catch (Exception processingEx) {
                    System.out.println("  ERROR while processing result for " + cmdLocalName + ": "
                            + processingEx.getMessage());
                    processingEx.printStackTrace();
                }
                return null;
            });

            state.inFlightProcessing.add(processing);
        }
    }

    /** Reads dip:commandSequenceNumber off a command individual, or returns
     *  Long.MIN_VALUE if it's absent (so such commands always sort first -
     *  they predate the generator, e.g. a hand-written example command). */
    private static long readSequenceNumber(Individual cmd, OntProperty seqProp) {
        if (seqProp == null) {
            return Long.MIN_VALUE;
        }
        Statement s = cmd.getProperty(seqProp);
        if (s == null) {
            return Long.MIN_VALUE;
        }
        try {
            return s.getLong();
        } catch (Exception e) {
            return Long.MIN_VALUE;
        }
    }

    // ============================================================
    //   RANDOM COMMAND GENERATOR (runs on its own background thread)
    // ============================================================
    /**
     * Stands in for whatever real, external system would normally be issuing
     * Diplodocus commands. Every few seconds (a random delay between
     * GEN_INTERVAL_MIN_MS and GEN_INTERVAL_MAX_MS), for a total of
     * GENERATOR_DURATION_MS, this method invents one new command with a
     * random packet size and a random start cycle, and appends it to
     * diplodocus.owl.ttl.
     */
    private static void runCommandGenerator() {
        Random rnd = new Random();
        long genEndTime = System.currentTimeMillis() + GENERATOR_DURATION_MS;
        int genCounter = 1;

        System.out.println("  [generator] Started - will inject random commands for "
                + (GENERATOR_DURATION_MS / 1000) + "s.");

        while (System.currentTimeMillis() < genEndTime) {
            try {
                long waitMs = GEN_INTERVAL_MIN_MS
                        + (long) (rnd.nextDouble() * (GEN_INTERVAL_MAX_MS - GEN_INTERVAL_MIN_MS));
                Thread.sleep(waitMs);

                int packetSize = RANDOM_PACKET_SIZES[rnd.nextInt(RANDOM_PACKET_SIZES.length)];
                int cycleValue = RANDOM_CYCLE_MIN + rnd.nextInt(RANDOM_CYCLE_MAX - RANDOM_CYCLE_MIN);
                String suffix  = "AutoCmd" + genCounter++;
                long   seqNum  = cmdSequenceCounter.getAndIncrement();

                synchronized (DIPLO_LOCK) {
                    appendNewCommand(suffix, packetSize, cycleValue, seqNum);
                }
                System.out.println("  [generator] Injected " + suffix
                        + "  (packetSize=" + packetSize + " bytes, cycleValue=" + cycleValue
                        + ", seq=" + seqNum + ")");
            } catch (InterruptedException ignored) {
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        System.out.println("  [generator] Finished - no more commands will be injected.");
    }

    /**
     * Appends one new dip:WriteChannelCommand individual (together with its
     * linked DataQuantity and CycleTimePoint individuals) to
     * diplodocus.owl.ttl. Uses a plain Jena Model (no reasoner attached)
     * since adding raw triples doesn't require any reasoning.
     *
     * IMPORTANT: must always be called from inside a
     * "synchronized (DIPLO_LOCK)" block.
     */
    private static void appendNewCommand(String suffix, int packetSize, int cycleValue, long seqNum) throws IOException {
        Model m = RDFDataMgr.loadModel(
                Paths.get("diplodocus.owl.ttl").toUri().toString(),
                org.apache.jena.riot.Lang.TURTLE);

        Resource clsDataQty   = m.getResource(DIP + "DataQuantity");
        Resource clsCycleTime = m.getResource(DIP + "CycleTimePoint");
        Resource clsWriteCmd  = m.getResource(DIP + "WriteChannelCommand");

        Property propDataSize   = m.createProperty(DIP + "DataSize");
        Property propCycleValue = m.createProperty(DIP + "cycleValue");
        Property propHasDataQty = m.createProperty(DIP + "hasDataQuantity");
        Property propStartsAt   = m.createProperty(DIP + "startsAtCycle");
        Property propSeqNum     = m.createProperty(DIP + "commandSequenceNumber");

        String dataQtyName = "EV_ChargingRequest_" + suffix + "_DataQty";
        String cycleName   = "EV_ChargingRequest_" + suffix + "_StartCycle";
        String cmdName     = "EV_ChargingRequest_" + suffix + "_WriteCmd";

        Resource dataQty = m.createResource(DIP + dataQtyName);
        dataQty.addProperty(RDF.type, clsDataQty);
        dataQty.addProperty(RDFS.comment, m.createLiteral(
                "Auto-generated random DataQuantity for " + suffix));
        dataQty.addLiteral(propDataSize,
                m.createTypedLiteral(String.valueOf(packetSize), XSDDatatype.XSDinteger));

        Resource cycle = m.createResource(DIP + cycleName);
        cycle.addProperty(RDF.type, clsCycleTime);
        cycle.addProperty(RDFS.comment, m.createLiteral(
                "Auto-generated random CycleTimePoint for " + suffix));
        cycle.addLiteral(propCycleValue,
                m.createTypedLiteral(String.valueOf((double) cycleValue), XSDDatatype.XSDdouble));

        Resource cmd = m.createResource(DIP + cmdName);
        cmd.addProperty(RDF.type, clsWriteCmd);
        cmd.addProperty(RDFS.comment, m.createLiteral(
                "Auto-generated random WriteChannelCommand " + suffix));
        cmd.addProperty(propHasDataQty, dataQty);
        cmd.addProperty(propStartsAt, cycle);
        cmd.addLiteral(propSeqNum, seqNum);

        try (FileOutputStream out = new FileOutputStream("diplodocus.owl.ttl")) {
            RDFDataMgr.write(out, m, RDFFormat.TURTLE_PRETTY);
        }
    }

    // ============================================================
    // Helper methods
    // ============================================================

    private static List<Individual> listIndividuals(OntModel model, OntClass cls) {
        List<Individual> result = new ArrayList<Individual>();
        if (cls == null) {
            return result;
        }
        ExtendedIterator<Individual> it = model.listIndividuals(cls);
        while (it.hasNext()) {
            result.add(it.next());
        }
        it.close();
        return result;
    }

    private static Individual getLinkedIndividual(OntModel model, Individual ind, OntProperty prop) {
        if (ind == null || prop == null) {
            return null;
        }
        Statement stmt = ind.getProperty(prop);
        if (stmt == null || !stmt.getObject().isResource()) {
            return null;
        }
        return model.getIndividual(stmt.getObject().asResource().getURI());
    }
}