package fr.telecom_paris.labsoc;

import java.io.*;
import java.net.*;
import java.util.Collection;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ============================================================================
 * Ns3RunnerVisual — manages one long-lived, CONCURRENT-capable NS-3 process
 * ============================================================================
 *
 * WHAT THIS CLASS DOES
 * -----------------------
 * NS-3 is a separate program (a C++ simulator), controlled here as an
 * external OS process, launched once via ns-3's own build tool
 * ("./ns3 run ..."). Instead of starting a brand-new NS-3 process for every
 * command, this class starts NS-3 ONCE and keeps it running for the whole
 * session:
 *
 *   - The FIRST command is passed as command-line arguments when the
 *     process is launched (see start()).
 *   - Every FOLLOWING command is sent to that SAME already-running process
 *     over a small UDP "control channel" on localhost (see sendCommandAsync()).
 *
 * CONCURRENT COMMANDS - NOT ONE-AT-A-TIME
 * -------------------------------------------
 * Earlier versions of this class exposed a BLOCKING waitForNextResult()
 * method: the caller had to wait for one command's result before sending the
 * next, meaning NS-3 only ever simulated one packet "in flight" at a time.
 * That does not reflect real network behaviour, where several packets can
 * legitimately be in transit at once - so this version is fully asynchronous
 * instead:
 *
 *   - Every command (the first one, via start(), and every later one, via
 *     sendCommandAsync()) is assigned its own unique numeric id and returns
 *     a java.util.concurrent.CompletableFuture<Double> immediately, WITHOUT
 *     waiting for NS-3 to answer.
 *   - The caller can keep submitting further commands right away - several
 *     can be "in flight" inside the NS-3 simulation at the same time.
 *   - A single background thread continuously reads NS-3's console output.
 *     Each time NS-3 reports a result, it includes the id of the command it
 *     belongs to:
 *
 *         RESULT_START
 *         commandId=<id>
 *         sendMeasuredLatencyNs=<value>       (or receiveMeasuredLatencyNs=<value>)
 *         RESULT_END
 *
 *     That id is used to look up and complete the matching
 *     CompletableFuture, regardless of the order in which different
 *     commands' results actually arrive.
 *
 * ONE COMMAND, TWO RESULTS (SEND + RECEIVE)
 * -------------------------------------------
 * A single command can produce two results: a SEND latency and a RECEIVE
 * latency. Each is reported in its own RESULT block with the same commandId.
 * The block's latency line decides which future is completed:
 *
 *   - sendMeasuredLatencyNs=...    -> the future returned by start() /
 *                                     sendCommandAsync()
 *   - receiveMeasuredLatencyNs=... -> the future returned by
 *                                     getReceiveFuture(id)
 *
 * Finally, once the whole simulation session is done, this class can also
 * launch NetAnim (NS-3's visual animation viewer) to display everything that
 * was simulated, using the trace file NS-3 produced along the way.
 */
public class Ns3RunnerVisualSyncUDP {

    // UDP port that the NS-3 script listens on for commands sent after the
    // process has already started (must match the port used in the .cc file).
    private static final int UDP_PORT = 9999;

    // Filesystem paths configured once, at construction time.
    private final String ns3HomeDir;     // root folder of the ns-3 installation
    private final String netAnimBinary;  // path to the NetAnim executable

    private Process ns3Process;          // the running NS-3 OS process
    private DatagramSocket udpClient;    // used to send commands to NS-3 over UDP
    private volatile boolean running = false; // true while the NS-3 process is alive

    // Every command ever sent gets its own unique id, used to match its
    // eventual result back to the right CompletableFuture below.
    private final AtomicInteger nextId = new AtomicInteger(0);

    // One entry per command that has been sent but not yet answered.
    // The background reader removes and completes an entry as soon as
    // NS-3 reports that command's SEND result.
    private final ConcurrentHashMap<Integer, CompletableFuture<Double>> pending =
            new ConcurrentHashMap<>();

    // Separate futures for the RECEIVE-side measured latency. An entry is
    // created by getReceiveFuture(id) and removed/completed by the reader
    // thread when NS-3 reports receiveMeasuredLatencyNs for that id.
    private final ConcurrentHashMap<Integer, CompletableFuture<Double>>
            pendingReceive = new ConcurrentHashMap<>();

    // Type of the RESULT block currently being parsed: "send", "receive",
    // or null (not set yet / outside a block). Only touched by the reader
    // thread.
    private String currentResultType = null;

    // Simulated NS-3 time (ns) at which each command was injected, reported by
    // NS-3 in an "INJECTION_TIME commandId=X injectionTimeNs=Y" line. The
    // latencies printed by NS-3 are ABSOLUTE times, so the reader subtracts
    // this value to get a latency RELATIVE to the injection.
    private final ConcurrentHashMap<Integer, Double> injectionTimes =
            new ConcurrentHashMap<>();

    public Ns3RunnerVisualSyncUDP(String ns3HomeDir, String netAnimBinary) {
        this.ns3HomeDir = ns3HomeDir;
        this.netAnimBinary = netAnimBinary;
    }

    /**
     * Starts the NS-3 process for the very FIRST command of the session, with
     * that command's parameters (and its id) passed directly as command-line
     * arguments. Must be called exactly once per session - every later
     * command should go through sendCommandAsync() instead, to reuse this
     * same running process.
     *
     * @param nsValue    the NS-3-side timing value for the link (nanoseconds),
     *                   computed from the Diplodocus cycle value via the
     *                   mapping ontology
     * @param packetSize the size, in bytes, of the packet to simulate sending
     * @return a future that completes with the measured latency in
     *         nanoseconds once NS-3 reports this command's result
     */
    /*public synchronized CompletableFuture<Double> start(double nsValue, int packetSize)
            throws IOException {
        if (running) {
            throw new IllegalStateException(
                    "Already running - use sendCommandAsync() for later commands");
        }

        int id = nextId.getAndIncrement();
        CompletableFuture<Double> future = new CompletableFuture<>();
        pending.put(id, future);

        // Build the "./ns3 run <scratch-script> --nsValue=... --packetSize=...
        // --id=..." command line and launch it as a child OS process.
        String ns3Args = String.format(
                "scratch/java-bridge-sim-Visual-RT2_Syn --nsValue=%f --packetSize=%d --id=%d",
                nsValue, packetSize, id
        );

        //RT>>ICMP from Cl without automatic thread generator of commands
        //RT1>>ICMP from Cl possibilité qu'une commande légère termine avant une lourd
        //     (ICMP from Cl with automatic thread generator of commands )
        //RT2>>ICMP from Cl surcharge progressive du reseau
        //RT2Gr>>ICMP from Gr surcharge progressive du reseau
        //TCPGr>>TCP from Gr
        //TCPGrRouter>> TCP avec router from Gr

        ProcessBuilder pb = new ProcessBuilder("./ns3", "run", ns3Args);
        pb.directory(new File(ns3HomeDir));
        pb.redirectErrorStream(true);
        ns3Process = pb.start();
        running = true;

        // Start a background thread that continuously reads everything NS-3
        // prints, and completes the matching future for every result found.
        Thread reader = new Thread(this::readOutputLoop, "ns3-stdout-reader");
        reader.setDaemon(true);
        reader.start();

        // Open the UDP socket used later by sendCommandAsync() to talk to
        // this same NS-3 process while it keeps running.
        udpClient = new DatagramSocket();

        return future;
    }*/

    public synchronized CompletableFuture<Double> start(double nsValue, int packetSize,
                                                        int direction, String transportFields)
            throws IOException {
        if (running) {
            throw new IllegalStateException(
                    "Already running - use sendCommandAsync() for later commands");
        }

        int id = nextId.getAndIncrement();
        CompletableFuture<Double> future = new CompletableFuture<>();
        pending.put(id, future);

        // DO NOT launch a new NS3 process - Diplodocus already launched it.
        // Just open the UDP socket to send commands to the existing process.
        udpClient = new DatagramSocket();
        running = true;

        // Start background reader that reads NS3 output from the log file
        // that Diplodocus redirected NS3's stdout to: /tmp/ns3_bridge.log
        Thread reader = new Thread(this::readOutputLoop, "ns3-stdout-reader");
        reader.setDaemon(true);
        reader.start();

        // Send the first transfer command to the existing NS3 process
        //String msg = "packetSize=" + packetSize + ";id=" + id;
        String msg = "packetSize=" + packetSize + ";id=" + id
                + ";nsValue=" + (long)nsValue + ";direction=" + direction
                + (transportFields == null ? "" : transportFields);
        
        byte[] data = msg.getBytes();
        udpClient.send(new DatagramPacket(
                data, data.length,
                InetAddress.getByName("127.0.0.1"), UDP_PORT));

        System.out.println(
                "  [bridge] First command sent to existing NS3: " + msg);

        return future;
    }

    /**
     * Runs on a dedicated background thread for as long as the NS-3 process is
     * alive. Reads every line NS-3 prints to its console, echoes it (prefixed
     * with "[ns3]") so it's visible while the simulation runs.
     *
     * A RESULT block carries ONE latency line, either:
     *
     *     sendMeasuredLatencyNs=<value>
     *
     * or:
     *
     *     receiveMeasuredLatencyNs=<value>
     *
     * The line type sets currentResultType, which decides at RESULT_END
     * which map (pending / pendingReceive) holds the future to complete.
     * If both lines were ever printed inside one block, only the last one
     * would be used - print them in two separate blocks.
     *
     * NS-3 prints ABSOLUTE times. Before a future is completed, the
     * command's injection time (from the INJECTION_TIME line) is subtracted,
     * so the value delivered to callers is relative to the injection.
     */
    private void readOutputLoop() {
        boolean insideResultBlock = false;
        Integer currentId = null;
        Double currentLatency = null;

        // Read from the log file that NS3 writes to:
        // /tmp/ns3_bridge.log
        //
        // Use a tail-like approach: keep reading and sleep when no new data.
        try {
            java.io.File logFile = new java.io.File("/tmp/ns3_bridge.log");

            // Wait for file to exist
            while (!logFile.exists()) {
                Thread.sleep(100);
            }

            java.io.RandomAccessFile raf = new java.io.RandomAccessFile(logFile, "r");

            // Seek to end so we only read NEW output
            raf.seek(raf.length());

            StringBuilder lineBuffer = new StringBuilder();

            while (running) {
                int b = raf.read();

                if (b == -1) {
                    // No new data yet - sleep briefly and retry
                    Thread.sleep(10);
                    continue;
                }

                char c = (char) b;

                if (c == '\n') {
                    String line = lineBuffer.toString().trim();
                    lineBuffer.setLength(0);

                    System.out.println("[ns3] " + line);

                    if (line.equals("RESULT_START")) {
                        insideResultBlock = true;

                        // Reset result information for the new block.
                        currentId = null;
                        currentLatency = null;
                        currentResultType = null;

                    } else if (line.equals("RESULT_END")) {
                        insideResultBlock = false;

                        if (currentId != null && currentLatency != null) {
                            // Injection time of this command (0 if NS-3 never
                            // reported one, i.e. the latency stays absolute).
                            Double inj = injectionTimes.get(currentId);
                            double injTime = (inj == null) ? 0.0 : inj;

                            // RELATIVE latency from injection
                            double relativeLatency = currentLatency - injTime;

                            if ("receive".equals(currentResultType)) {
                                // Receive result -> complete receive future
                                CompletableFuture<Double> f = pendingReceive.remove(currentId);
                                if (f != null) f.complete(relativeLatency);
                            } else {
                                // Send result (or untyped) -> complete send future
                                CompletableFuture<Double> f = pending.remove(currentId);
                                if (f != null) f.complete(relativeLatency);
                            }
                        }
                        currentResultType = null;
                        currentLatency = null;
                        currentId = null;

                    } else if (line.startsWith("INJECTION_TIME ")) {
                        // Parse: INJECTION_TIME commandId=X injectionTimeNs=Y
                        String[] parts = line.split("\\s+");
                        int injId = -1;
                        double injTime = 0;
                        for (String part : parts) {
                            if (part.startsWith("commandId="))
                                injId = Integer.parseInt(part.split("=", 2)[1].trim());
                            if (part.startsWith("injectionTimeNs="))
                                injTime = Double.parseDouble(part.split("=", 2)[1].trim());
                        }
                        if (injId >= 0) injectionTimes.put(injId, injTime);

                    } else if (insideResultBlock && line.startsWith("commandId=")) {
                        currentId = Integer.parseInt(
                                line.split("=", 2)[1].trim());

                    } else if (insideResultBlock && line.startsWith("sendMeasuredLatencyNs=")) {
                        currentLatency = Double.parseDouble(line.split("=", 2)[1].trim());
                        currentResultType = "send";

                    } else if (insideResultBlock && line.startsWith("receiveMeasuredLatencyNs=")) {
                        currentLatency = Double.parseDouble(line.split("=", 2)[1].trim());
                        currentResultType = "receive";
                    }

                } else {
                    lineBuffer.append(c);
                }
            }

            raf.close();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            running = false;

            // Complete pending SEND futures exceptionally.
            for (CompletableFuture<Double> f : pending.values()) {
                f.completeExceptionally(
                        new IOException("NS3 reader stopped"));
            }
            pending.clear();

            // Complete pending RECEIVE futures exceptionally as well.
            for (CompletableFuture<Double> f : pendingReceive.values()) {
                f.completeExceptionally(
                        new IOException("NS3 reader stopped"));
            }
            pendingReceive.clear();
        }
    }

    /**
     * Sends an ADDITIONAL command to the already-running NS-3 process over
     * the UDP control channel, WITHOUT waiting for any earlier command's
     * result - several commands can be "in flight" inside the simulation at
     * once. Returns a future that completes independently, whenever NS-3
     * reports THIS specific command's result.
     */
    public synchronized CompletableFuture<Double> sendCommandAsync(double nsValue, int packetSize,
            int direction, String transportFields) throws IOException {
        if (!running) {
            throw new IllegalStateException(
                    "Simulation is not running - call start() first");
        }

        int id = nextId.getAndIncrement();
        CompletableFuture<Double> future = new CompletableFuture<>();
        pending.put(id, future);

        String msg = "packetSize=" + packetSize + ";id=" + id
                + ";nsValue=" + (long) nsValue + ";direction=" + direction
                + transportFields;
        byte[] data = msg.getBytes();
        udpClient.send(new DatagramPacket(
                data, data.length,
                InetAddress.getByName("127.0.0.1"), UDP_PORT));

        System.out.println(
                "  [bridge] Commande envoyée à NS3: " + msg);

        return future;
    }

    //
    // This is my modification to allow synchornisation between Diplodocus and NS3
    //
    /*public CompletableFuture<Double> sendCommandAsync(
            int packetSize, long timesliceNs) throws IOException {

        int id = nextId.getAndIncrement();
        CompletableFuture<Double> future = new CompletableFuture<>();
        pending.put(id, future);

        String msg = "packetSize=" + packetSize
                + ";id=" + id
                + ";timesliceNs=" + timesliceNs;

        byte[] data = msg.getBytes();
        udpClient.send(new DatagramPacket(
                data, data.length,
                InetAddress.getByName("127.0.0.1"), UDP_PORT));

        System.out.println(
                "  [bridge] Command sent to NS3: " + msg);

        return future;
    }*/

    /**
     * Returns a separate future for the RECEIVE latency associated with
     * the specified command id.
     *
     * The receive future is completed when NS-3 reports:
     *
     *     receiveMeasuredLatencyNs=<value>
     *
     * inside a RESULT block carrying this command's id. Call this BEFORE
     * submitting the command, so the future is registered before NS-3 can
     * possibly answer.
     */
    public CompletableFuture<Double> getReceiveFuture(int id) {
        CompletableFuture<Double> f = new CompletableFuture<>();
        pendingReceive.put(id, f);
        return f;
    }

    /**
     * Returns every command's future that has been sent but not yet
     * answered. Used, at the end of a session, to wait for any results that
     * are still "in flight" before shutting down.
     */
    public Collection<CompletableFuture<Double>> pendingFutures() {
        return pending.values();
    }

    /**
     * Opens NetAnim (NS-3's graphical animation viewer) pointed at the trace
     * file NS-3 produced during the simulation, so the whole session can be
     * watched visually. Launched as its own independent process (no
     * waitFor()), so this call returns immediately.
     */
    public void launchNetAnim(String xmlPath) throws IOException {
        ProcessBuilder animPb = new ProcessBuilder(netAnimBinary, xmlPath);
        animPb.inheritIO();
        animPb.start();
    }

    /** Forcibly terminates the NS-3 process and closes the UDP socket. */
    public void stopAndClose() {
        if (ns3Process != null) {
            ns3Process.destroy();
        }
        if (udpClient != null) {
            udpClient.close();
        }
        running = false;
    }

    /**
     * Blocks until the NS-3 process exits on its own (i.e. until it reaches
     * its own internal Simulator::Stop(...) time), rather than being killed
     * from the outside. This guarantees NS-3 has had the chance to fully
     * flush and close its NetAnim trace file before that file gets opened
     * for viewing.
     */
    public boolean waitForNs3ToFinish(long timeoutSeconds)
            throws InterruptedException {
        return ns3Process.waitFor(
                timeoutSeconds, TimeUnit.SECONDS);
    }

    public boolean isRunning() {
        return running;
    }
}