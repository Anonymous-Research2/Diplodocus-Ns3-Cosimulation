package fr.telecom_paris.labsoc;

import org.apache.jena.datatypes.xsd.XSDDatatype;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.rdf.model.*;
import org.apache.jena.reasoner.ValidityReport;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.vocabulary.RDF;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import openllet.jena.PelletReasonerFactory;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Paths;
import java.util.*;

/**
 * Start-up check of a TTool model before co-simulation.
 *
 *  1. parse()      reads the TTool .xml: NI tasks (tasks mapped on a
 *                  "Network Interface"), the channels they handle, the port
 *                  attributes of those channels and their mapping (Network / Bus).
 *  2. toRdf()      turns them into Diplodocus individuals
 *                  (Channel, NetTask, Network, Bus, handlesChannel, mappedOn, ...).
 *  3. reason()     loads diplodocus + ns3 + mapping with Openllet and
 *                  - checks consistency,
 *                  - if consistent: reads the inferred transport (TcpSocket /
 *                    UdpSocket) and its parameter (sndBufSize / errorRate),
 *                  - if inconsistent: checks each network channel alone to find
 *                    which one cannot be co-simulated, and explains why.
 *  4. writeResult() writes the verdict for Diplodocus (C++).
 */
public class ModelChecker {

    static final String DIP = "http://labsoc.telecom-paris.fr/diplodocus#";
    static final String NS3 = "http://labsoc.telecom-paris.fr/ns3#";
    public static final String RESULT_FILE =
            "/home/isso84/TTool-ns3/simulators/c++2/net_check.result";
    /** Network topology read from the model, used by the NS-3 script. */
    public static final String TOPOLOGY_FILE =
            "/home/isso84/TTool-ns3/simulators/c++2/net_topology.conf";

    /** Network nodes of the architecture: name -> bandwidth in bit/s */
    final Map<String, Long> niBandwidth      = new LinkedHashMap<>();
    final Map<String, Long> networkBandwidth = new LinkedHashMap<>();
    final Map<String, String> networkPropSpeed = new LinkedHashMap<>();
    final Map<String, Long> routerBandwidth  = new LinkedHashMap<>();
    /** NI task (short name) -> Network Interface node it is mapped on */
    final Map<String, String> taskNi = new LinkedHashMap<>();
    /** {node name, network name}: an NI or a router connected to a network */
    final List<String[]> attachments = new ArrayList<>();

    /** TTool bandwidth + unit -> bit/s (unit: 0 = kb/s, 1 = Mb/s, 2 = Gb/s) */
    static long toBps(String bw, String unit) {
        try {
            double v = Double.parseDouble(bw.trim());
            int u = unit == null || unit.isEmpty() ? 1 : Integer.parseInt(unit.trim());
            double mult = u == 0 ? 1e3 : (u == 2 ? 1e9 : 1e6);
            return (long) (v * mult);
        } catch (Exception e) {
            return 0;
        }
    }

    /** One TTool channel handled by at least one NI task. */
    static class ChannelInfo {
        String name;                       // e.g. measPktOut__measPktIn
        String originTask = "?", destTask = "?";
        boolean blocking, lossy;
        int lossPct, maxLoss, capacity, width;
        List<String> networks = new ArrayList<>();
        List<String> buses    = new ArrayList<>();
        boolean onNetwork() { return !networks.isEmpty(); }
        String id() { return "Ch_" + safe(name); }
    }

    private final String xmlPath;
    final Set<String> niTasks = new LinkedHashSet<>();
    final List<ChannelInfo> channels = new ArrayList<>();
    final List<String> report = new ArrayList<>();   // lines written to RESULT_FILE
    boolean consistent = true;
    /** sender NI task (short name) -> extra command fields for NS3,
     *  e.g. ";transport=UDP;errorRate=0.02" or ";transport=TCP;sndBuf=32" */
    final Map<String, String> transportFields = new HashMap<>();

    public ModelChecker(String xmlPath) { this.xmlPath = xmlPath; }

    static boolean isNetworkNode(String stereotype) {
        return stereotype.equals("Network Interface") || stereotype.equals("Network Router");
    }

    static String safe(String s) { return s.replaceAll("[^A-Za-z0-9_]", "_"); }

    private void out(String line) {
        System.out.println(line);
        report.add(line);
    }

    // ==================================================================
    // 1. Parse the TTool model
    // ==================================================================
    private static Element child(Element e, String tag) {
        for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling())
            if (n instanceof Element && ((Element) n).getTagName().equals(tag))
                return (Element) n;
        return null;
    }

    public void parse() throws Exception {
        Document doc = DocumentBuilderFactory.newInstance()
                .newDocumentBuilder().parse(new java.io.File(xmlPath));

        Map<String, String>   taskById  = new HashMap<>();   // component id -> task name
        Map<String, String[]> nodeById  = new HashMap<>();   // archi id -> {stereotype, nodeName}
        Map<String, Element>  portOut   = new HashMap<>();   // commName -> Prop (origin=true)
        Map<String, Element>  portIn    = new HashMap<>();   // commName -> Prop (origin=false)
        Map<String, String>   portTask  = new HashMap<>();   // "out:"/"in:"+commName -> task
        List<String[]>        taskArt   = new ArrayList<>(); // {nodeId, taskName}
        List<Element>         chanArt   = new ArrayList<>();
        Map<Element, String>  chanNode  = new HashMap<>();
        Map<String, String>   pointOwner = new HashMap<>();  // connecting point id -> component id

        NodeList all = doc.getElementsByTagName("*");
        // first pass: tasks and architecture nodes
        for (int i = 0; i < all.getLength(); i++) {
            Element e = (Element) all.item(i);
            String tag = e.getTagName();
            if (!tag.equals("COMPONENT") && !tag.equals("SUBCOMPONENT")) continue;
            String id = e.getAttribute("id");
            for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling())
                if (n instanceof Element && ((Element) n).getTagName().equals("TGConnectingPoint"))
                    pointOwner.put(((Element) n).getAttribute("id"), id);
            Element ip = child(e, "infoparam");
            Element ex = child(e, "extraparam");
            if (e.getAttribute("type").equals("1202") && ip != null)       // TML primitive component
                taskById.put(id, ip.getAttribute("value"));
            if (ex != null) {
                Element info = child(ex, "info");
                if (info != null && info.hasAttribute("stereotype")) {
                    nodeById.put(id, new String[]{info.getAttribute("stereotype"),
                                                  info.getAttribute("nodeName")});
                    // network attributes of the architecture nodes
                    Element at = child(ex, "attributes");
                    String st = info.getAttribute("stereotype"), nn = info.getAttribute("nodeName");
                    if (at != null && at.hasAttribute("bandwidth")) {
                        long bps = toBps(at.getAttribute("bandwidth"), at.getAttribute("unit"));
                        if (st.equals("Network Interface")) niBandwidth.put(nn, bps);
                        else if (st.equals("Network Router")) routerBandwidth.put(nn, bps);
                        else if (st.equals("Network")) {
                            networkBandwidth.put(nn, bps);
                            networkPropSpeed.put(nn, at.getAttribute("propagationSpeed"));
                        }
                    }
                }
            }
        }
        // second pass: ports and mapping artifacts
        for (int i = 0; i < all.getLength(); i++) {
            Element e = (Element) all.item(i);
            String tag = e.getTagName();
            if (!tag.equals("COMPONENT") && !tag.equals("SUBCOMPONENT")) continue;
            Element father = child(e, "father");
            String fid = father == null ? null : father.getAttribute("id");
            Element ex = child(e, "extraparam");
            if (ex == null) continue;

            Element prop = child(ex, "Prop");
            if (prop != null && prop.hasAttribute("commName") && fid != null) {
                String cn = prop.getAttribute("commName");
                boolean origin = "true".equals(prop.getAttribute("origin"));
                (origin ? portOut : portIn).put(cn, prop);
                portTask.put((origin ? "out:" : "in:") + cn, taskById.getOrDefault(fid, "?"));
            }
            Element info = child(ex, "info");
            if (info != null && fid != null) {
                if ("channel".equals(info.getAttribute("typeName"))) {
                    chanArt.add(info);
                    chanNode.put(info, fid);
                } else if (info.hasAttribute("taskName")) {
                    taskArt.add(new String[]{fid, info.getAttribute("taskName")});
                }
            }
        }

        // NI tasks = tasks mapped on a Network Interface node
        for (String[] ta : taskArt) {
            String[] node = nodeById.get(ta[0]);
            if (node != null && node[0].equals("Network Interface")) {
                niTasks.add(ta[1]);
                taskNi.put(ta[1], node[1]);
            }
        }

        // topology: connectors between an NI / a router and a network
        NodeList conns = doc.getElementsByTagName("CONNECTOR");
        for (int i = 0; i < conns.getLength(); i++) {
            Element c = (Element) conns.item(i);
            Element p1 = child(c, "P1"), p2 = child(c, "P2");
            if (p1 == null || p2 == null) continue;
            String[] a = nodeById.get(pointOwner.get(p1.getAttribute("id")));
            String[] b = nodeById.get(pointOwner.get(p2.getAttribute("id")));
            if (a == null || b == null) continue;
            if (b[0].equals("Network") && isNetworkNode(a[0])) attachments.add(new String[]{a[1], b[1]});
            else if (a[0].equals("Network") && isNetworkNode(b[0])) attachments.add(new String[]{b[1], a[1]});
        }

        // channels: group mapping artifacts by communicationName
        Map<String, ChannelInfo> byName = new LinkedHashMap<>();
        for (Element info : chanArt) {
            String cname = info.getAttribute("communicationName");
            ChannelInfo ch = byName.computeIfAbsent(cname, k -> {
                ChannelInfo c = new ChannelInfo();
                c.name = k;
                return c;
            });
            String[] node = nodeById.get(chanNode.get(info));
            if (node != null) {
                if (node[0].equals("Network") && !ch.networks.contains(node[1])) ch.networks.add(node[1]);
                if (node[0].toUpperCase().startsWith("BUS") && !ch.buses.contains(node[1])) ch.buses.add(node[1]);
            }
            for (String b : info.getAttribute("mappedElements").split(","))
                if (!b.trim().isEmpty() && !ch.buses.contains(b.trim())) ch.buses.add(b.trim());
        }

        for (ChannelInfo ch : byName.values()) {
            int p = ch.name.indexOf("__");
            if (p < 0) continue;
            String out = ch.name.substring(0, p), in = ch.name.substring(p + 2);
            Element prop = portOut.containsKey(out) ? portOut.get(out) : portIn.get(in);
            if (prop == null) continue;
            ch.originTask = portTask.getOrDefault("out:" + out, "?");
            ch.destTask   = portTask.getOrDefault("in:" + in, "?");
            ch.blocking = "true".equals(prop.getAttribute("blocking"));
            ch.lossy    = "true".equals(prop.getAttribute("isLossy"));
            ch.lossPct  = parseInt(prop.getAttribute("lossPercentage"));
            ch.maxLoss  = parseInt(prop.getAttribute("maxNbOfLoss"));
            ch.capacity = parseInt(prop.getAttribute("maxSamples"));
            ch.width    = parseInt(prop.getAttribute("widthSamples"));
            // keep only channels handled by an NI task
            if (niTasks.contains(ch.originTask) || niTasks.contains(ch.destTask))
                channels.add(ch);
        }

        out("  [model-check] TTool model : " + xmlPath);
        out("  [model-check] NI tasks    : " + niTasks);
        for (ChannelInfo ch : channels)
            out("  [model-check] channel " + ch.name + "  " + ch.originTask + " -> " + ch.destTask
                + "  mapped on " + (ch.onNetwork() ? "Network " + ch.networks : "Bus " + ch.buses)
                + "  blocking=" + ch.blocking + " lossy=" + ch.lossy
                + " loss%=" + ch.lossPct + " capacity=" + ch.capacity + " width=" + ch.width);
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    // ==================================================================
    // 2. Individuals for the Diplodocus ontology
    // ==================================================================
    public Model toRdf() {
        Model m = ModelFactory.createDefaultModel();
        m.setNsPrefix("", DIP);
        for (ChannelInfo ch : channels) addChannel(m, ch);
        addTopology(m);
        for (String t : niTasks) {
            Resource task = m.createResource(DIP + safe(t));
            task.addProperty(RDF.type, m.createResource(DIP + "NetTask"));
            if (taskNi.containsKey(t))
                task.addProperty(m.createProperty(DIP + "executesOn"),
                                 m.createResource(DIP + "Arch_" + safe(taskNi.get(t))));
            for (ChannelInfo ch : channels) {
                if (!t.equals(ch.originTask) && !t.equals(ch.destTask)) continue;
                Resource c = m.createResource(DIP + ch.id());
                task.addProperty(m.createProperty(DIP + "handlesChannel"), c);
                if (t.equals(ch.originTask)) task.addProperty(m.createProperty(DIP + "writesChannel"), c);
                if (t.equals(ch.destTask))   task.addProperty(m.createProperty(DIP + "readsChannel"),  c);
            }
        }
        return m;
    }

    /** Network Interfaces, routers, networks, their bandwidths and connections. */
    private void addTopology(Model m) {
        Property bw = m.createProperty(DIP + "bandwidthBps");
        for (Map.Entry<String, Long> e : niBandwidth.entrySet()) {
            Resource r = m.createResource(DIP + "Arch_" + safe(e.getKey()));
            r.addProperty(RDF.type, m.createResource(DIP + "NetworkInterface"));
            r.addLiteral(bw, m.createTypedLiteral(String.valueOf(e.getValue()), XSDDatatype.XSDlong));
        }
        for (Map.Entry<String, Long> e : routerBandwidth.entrySet()) {
            Resource r = m.createResource(DIP + "Arch_" + safe(e.getKey()));
            r.addProperty(RDF.type, m.createResource(DIP + "NetworkRouter"));
            r.addLiteral(bw, m.createTypedLiteral(String.valueOf(e.getValue()), XSDDatatype.XSDlong));
        }
        for (Map.Entry<String, Long> e : networkBandwidth.entrySet()) {
            Resource r = m.createResource(DIP + "Arch_" + safe(e.getKey()));
            r.addProperty(RDF.type, m.createResource(DIP + "Network"));
            r.addLiteral(bw, m.createTypedLiteral(String.valueOf(e.getValue()), XSDDatatype.XSDlong));
            String ps = networkPropSpeed.get(e.getKey());
            if (ps != null && ps.trim().matches("-?\\d+"))
                r.addLiteral(m.createProperty(DIP + "propagationSpeed"),
                        m.createTypedLiteral(ps.trim(), XSDDatatype.XSDinteger));
        }
        for (String[] at : attachments)
            m.createResource(DIP + "Arch_" + safe(at[0])).addProperty(
                    m.createProperty(DIP + "attachedTo"),
                    m.createResource(DIP + "Arch_" + safe(at[1])));
    }

    private void addChannel(Model m, ChannelInfo ch) {
        Resource c = m.createResource(DIP + ch.id());
        c.addProperty(RDF.type, m.createResource(DIP + "Channel"));
        c.addProperty(m.createProperty(DIP + "channelName"), ch.name);
        c.addLiteral(m.createProperty(DIP + "isBlocking"), m.createTypedLiteral(ch.blocking));
        c.addLiteral(m.createProperty(DIP + "isLossy"),    m.createTypedLiteral(ch.lossy));
        c.addLiteral(m.createProperty(DIP + "lossPercentage"),
                m.createTypedLiteral(String.valueOf(ch.lossPct), XSDDatatype.XSDinteger));
        c.addLiteral(m.createProperty(DIP + "maxNbOfLoss"),
                m.createTypedLiteral(String.valueOf(ch.maxLoss), XSDDatatype.XSDinteger));
        c.addLiteral(m.createProperty(DIP + "capacitySamples"),
                m.createTypedLiteral(String.valueOf(ch.capacity), XSDDatatype.XSDinteger));
        c.addLiteral(m.createProperty(DIP + "widthBytes"),
                m.createTypedLiteral(String.valueOf(ch.width), XSDDatatype.XSDinteger));
        for (String n : ch.networks) {
            Resource r = m.createResource(DIP + "Arch_" + safe(n));
            r.addProperty(RDF.type, m.createResource(DIP + "Network"));
            c.addProperty(m.createProperty(DIP + "mappedOn"), r);
        }
        for (String b : ch.buses) {
            Resource r = m.createResource(DIP + "Arch_" + safe(b));
            r.addProperty(RDF.type, m.createResource(DIP + "Bus"));
            c.addProperty(m.createProperty(DIP + "mappedOn"), r);
        }
    }

    // ==================================================================
    // 3. Reasoning
    // ==================================================================
    private static OntModel load(Model diplo) {
        OntModel ont = ModelFactory.createOntologyModel(PelletReasonerFactory.THE_SPEC);
        ont.add(diplo);
        ont.read(Paths.get("ns3.owl.ttl").toUri().toString(), "TURTLE");
        ont.read(Paths.get("mapping.owl.ttl").toUri().toString(), "TURTLE");
        return ont;
    }

    private static boolean isConsistent(OntModel ont) {
        try {
            ValidityReport vr = ont.validate();
            return vr.isValid();
        } catch (Exception e) {          // Openllet may throw InconsistentOntologyException
            return false;
        }
    }

    /**
     * @param diploWithIndividuals diplodocus.owl.ttl content, already holding toRdf()
     * @param tbox                 diplodocus.owl.ttl content WITHOUT the generated individuals
     */
    public void reason(Model diploWithIndividuals, Model tbox) {
        out("  [model-check] Running Openllet on diplodocus + ns3 + mapping ...");
        OntModel ont = load(diploWithIndividuals);
        consistent = isConsistent(ont);

        if (consistent) {
            out("  [model-check] Reasoner: ontology CONSISTENT -> the model can be co-simulated.");
            reportTransports(ont);
        } else {
            out("  [model-check] Reasoner: ontology INCONSISTENT -> the model CANNOT be co-simulated faithfully.");
            explain(tbox);
        }
    }

    private void reportTransports(OntModel ont) {
        OntClass tcp = ont.getOntClass(NS3 + "TcpSocket");
        OntClass udp = ont.getOntClass(NS3 + "UdpSocket");
        Property sndBuf = ont.getProperty(NS3 + "sndBufSize");
        Property errRate = ont.getProperty(NS3 + "errorRate");

        for (ChannelInfo ch : channels) {
            if (!ch.onNetwork()) continue;
            Individual sender = ont.getIndividual(DIP + safe(ch.originTask));
            String transport = "?", param = "", why = "";
            if (sender != null && sender.hasOntClass(udp)) {
                transport = "UDP";
                Statement s = sender.getProperty(errRate);
                param = "errorRate=" + (s != null ? s.getObject().asLiteral().getLexicalForm()
                                                  : (ch.lossPct / 100.0) + " (computed, SWRL value missing)");
                why = "lossy channel: losses must reach the reader, TCP would hide them";
            } else if (sender != null && sender.hasOntClass(tcp)) {
                transport = "TCP";
                Statement s = sender.getProperty(sndBuf);
                param = "sndBufSize=" + (s != null ? s.getObject().asLiteral().getLexicalForm()
                                                   : (ch.capacity * ch.width) + " (computed, SWRL value missing)");
                why = ch.blocking ? "blocking channel: TCP backpressure reproduces the blocking write"
                                  : "lossless channel: TCP gives reliable delivery";
            }
            out("  [model-check] channel " + ch.name + " (" + ch.originTask + " -> " + ch.destTask
                + "): we need a " + transport + " transport, " + param + "  [" + why + "]");
            String value = param.replaceAll(" .*$", "");       // drop "(computed...)" note
            transportFields.put(ch.originTask, ";transport=" + transport + ";" + value);
            report.add("TRANSPORT " + ch.originTask + " " + ch.destTask + " " + transport + " " + param);
        }
    }

    /** Checks every network channel alone to find the one(s) that cannot be co-simulated. */
    private void explain(Model tbox) {
        for (ChannelInfo ch : channels) {
            if (!ch.onNetwork()) continue;
            Model one = ModelFactory.createDefaultModel();
            one.add(tbox);
            addChannel(one, ch);
            for (String t : new String[]{ch.originTask, ch.destTask}) {
                if (!niTasks.contains(t)) continue;
                Resource task = one.createResource(DIP + safe(t));
                task.addProperty(RDF.type, one.createResource(DIP + "NetTask"));
                task.addProperty(one.createProperty(DIP + "handlesChannel"),
                                 one.createResource(DIP + ch.id()));
            }
            if (isConsistent(load(one))) continue;

            out("  [model-check] CONFLICT on channel " + ch.name + " ("
                + ch.originTask + " -> " + ch.destTask + "):");
            out("      NetworkChannel      : mapped on Network " + ch.networks);
            if (ch.blocking)
                out("      BackpressureChannel : isBlocking=true  => its NI tasks must be ns3:TcpSocket");
            if (!ch.lossy)
                out("      LosslessChannel     : isLossy=false   => its NI tasks must be ns3:TcpSocket");
            if (ch.lossy)
                out("      LossyChannel        : isLossy=true (" + ch.lossPct
                    + "%) => its NI tasks must be ns3:UdpSocket");
            out("      ns3:TcpSocket owl:disjointWith ns3:UdpSocket  => no individual can be both: inconsistency.");
            out("      Accepted by TTool, but no single ns-3 transport reproduces this channel."
                + " Fix: make it non-blocking (-> UDP) or lossless (-> TCP).");
            report.add("CONFLICT " + ch.name + " " + ch.originTask + " " + ch.destTask);
        }
    }

    // ==================================================================
    // 4. Verdict for Diplodocus
    // ==================================================================
    public void writeResult() {
        writeTopology();
        try (PrintWriter pw = new PrintWriter(new FileWriter(RESULT_FILE))) {
            pw.println(consistent ? "CONSISTENT" : "INCONSISTENT");
            for (String l : report) pw.println(l);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /** Writes the network topology of the model for the NS-3 script:
     *    router <name>              (only if the model has a Network Router)
     *    routerBps <bit/s>
     *    ni <NIname> <bit/s>        (one line per Network Interface)
     *    network <name> <bit/s> <propagationSpeed as written in the model>  */
    private String attachmentsText() {
        StringBuilder sb = new StringBuilder("[");
        for (String[] a : attachments) sb.append(sb.length() > 1 ? ", " : "").append(a[0]).append("-").append(a[1]);
        return sb.append("]").toString();
    }

    public void writeTopology() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(TOPOLOGY_FILE))) {
            for (Map.Entry<String, Long> e : routerBandwidth.entrySet()) {
                pw.println("router " + e.getKey());
                pw.println("routerBps " + e.getValue());
            }
            for (Map.Entry<String, Long> e : niBandwidth.entrySet())
                pw.println("ni " + e.getKey() + " " + e.getValue());
            for (Map.Entry<String, Long> e : networkBandwidth.entrySet())
                pw.println("network " + e.getKey() + " " + e.getValue()
                           + " " + networkPropSpeed.getOrDefault(e.getKey(), ""));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("  [model-check] topology: "
                + (routerBandwidth.isEmpty() ? "no router" : "router " + routerBandwidth)
                + ", NI bandwidths " + niBandwidth
                + ", networks " + networkBandwidth
                + ", connections " + attachmentsText()
                + " -> " + TOPOLOGY_FILE);
    }

    /** Writes an error verdict (for example when the model file cannot be read). */
    public static void writeError(String msg) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RESULT_FILE))) {
            pw.println("ERROR");
            pw.println(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static String stack(Exception e) {
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }
}
